#!/bin/bash
# Source-only temporary assembly: never alters either Chronos checkout or checkpoint.
set -euo pipefail
REPO="$HOME/chronos-urf-rr"
BASE="$REPO/tools/research-agent-toolkit"
CHECKPOINT="$HOME/Documents/URF-AI-checkpoints/scientific-40pass-20261120-022542"
PY="$REPO/.venv/bin/python"
EXPECTED_HEAD="605aca6330c7b834c09eae77275763b8a374f864"
HERE="$(cd "$(dirname "$0")" && pwd -P)"
[ -x "$PY" ] || { echo 'BLOCKED := PYTHON_MISSING'; exit 1; }
[ -d "$BASE/src/research_agent_toolkit" ] || { echo 'BLOCKED := FRAMEWORK_MISSING'; exit 1; }
[ -f "$CHECKPOINT/src/research_agent_toolkit/scientific.py" ] || { echo 'BLOCKED := CHECKPOINT_MISSING'; exit 1; }
[ "$(git -C "$REPO" rev-parse HEAD)" = "$EXPECTED_HEAD" ] || { echo 'BLOCKED := CHRONOS_REVISION_CHANGED'; exit 1; }
[ -z "${GIT_DIR:-}" ] && [ -z "${GIT_WORK_TREE:-}" ] || { echo 'BLOCKED := GIT_ENVIRONMENT_OVERRIDE'; exit 1; }
# Verify provenance of preserved scientific source; no blind mixing of revisions.
CHECK_HASHES="$(
 cd "$CHECKPOINT/src/research_agent_toolkit"
 shasum -a 256 cli.py scientific.py science_sources.py
)"
printf '%s\n' "$CHECK_HASHES" | grep -q '^4c45df4dcf5b02dbd88b950c4aa6f350f096474124804c755d0cbb271e2a2bea  cli.py$' || { echo 'BLOCKED := CLI_HASH_CHANGED'; exit 1; }
printf '%s\n' "$CHECK_HASHES" | grep -q '^9986a6cee01e2cecd3f85c36d8e1501c3d1fd2894fd1ae8859a1155b1214dabe  scientific.py$' || { echo 'BLOCKED := SCIENTIFIC_HASH_CHANGED'; exit 1; }
printf '%s\n' "$CHECK_HASHES" | grep -q '^64e2268a012d53b6276d05e63397a5510305e3242ff95e737c02a3d813886f18  science_sources.py$' || { echo 'BLOCKED := SOURCES_HASH_CHANGED'; exit 1; }
WORK="$(mktemp -d)"
mkdir -p "$WORK/science_src"
cp -R "$BASE/src/research_agent_toolkit" "$WORK/science_src/"
cp "$CHECKPOINT/src/research_agent_toolkit/"*.py "$WORK/science_src/research_agent_toolkit/"
for NAME in cli.py scientific.py science_sources.py; do
 cmp "$CHECKPOINT/src/research_agent_toolkit/$NAME" "$WORK/science_src/research_agent_toolkit/$NAME" || exit 1
done
printf 'TEMP_ASSEMBLY := %s\n' "$WORK"
export URF_SCIENCE_STAGE="$WORK/science_src"
export URF_SCIENCE_REPO="$REPO"
export PYTHONDONTWRITEBYTECODE=1
cd "$HERE"
echo '=== GUI AND SCIENCE BRIDGE TESTS ==='
"$PY" -B -m unittest -q \
 test_docker_bridge test_host_math_check test_research_console \
 test_exact_question test_simple_console_http test_eval_solve \
 test_equation_intent test_counterexample test_human_verdict test_scientific_gui_bridge
printf 'LOCAL_INTEGRATION_TESTS := PASS\n'
echo '=== START GUI (Ctrl+C to stop) ==='
"$PY" -B research_console.py
