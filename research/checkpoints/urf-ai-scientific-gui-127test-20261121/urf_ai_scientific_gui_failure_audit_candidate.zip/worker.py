"""Data-only container worker: no candidate Python or repo access."""
from __future__ import annotations
import hashlib, json, pathlib, sys
from scientific_adapter import parse_trial
from fractions import Fraction
from host_bound_adapter import verify_host_bound

BASELINE=pathlib.Path('/input/baseline.json').read_bytes()
r=verify_host_bound(BASELINE)
# Derive correction witness from the actual verified candidate, not a status flag.
# Fail closed if the authorized host gate did not accept the fixed fixture.
if r.status != 'HOST_BOUND_FIXTURE_PASS_NOT_PROMOTED':
    sys.exit(2)
left, right = parse_trial(BASELINE)
from registry_backtracking import verify_registered_task
reg = verify_registered_task(BASELINE, task_id='linear-1-plus-2x-v1')
if reg.correction is None or reg.correction.outcome is None or reg.correction.outcome.accepted_candidate is None:
    sys.exit(2)
_, corrected = parse_trial(reg.correction.outcome.accepted_candidate)
def format_fraction(f):
    return str(f.numerator) if f.denominator == 1 else str(f.numerator)+'/'+str(f.denominator)
# Emit one machine-readable record; no user-requested status is trusted.
print(json.dumps({
 'status':r.status,
 'baseline_sha256':r.baseline_sha256,
 'registered_evidence_sha256':r.registered_evidence_sha256,
 'input_sha256':hashlib.sha256(BASELINE).hexdigest(),
 'corrected_coefficients':[format_fraction(f) for f in corrected],
},sort_keys=True,separators=(',',':')))
sys.exit(0 if r.status == 'HOST_BOUND_FIXTURE_PASS_NOT_PROMOTED' else 2)
