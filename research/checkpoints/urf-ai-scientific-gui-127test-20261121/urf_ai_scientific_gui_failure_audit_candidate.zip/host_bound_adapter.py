"""Research-only host-bound API. Trusted host configuration is not supplied by request.

The pinned policy below is a demonstration fixture, not an authenticated external
configuration. Passing tests proves API contract only, not production isolation.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from registry_backtracking import verify_registered_task
from trusted_registry import lookup, fixture_digest

@dataclass(frozen=True)
class HostVerdict:
    status: str
    baseline_sha256: str | None
    registered_evidence_sha256: str | None

# Fixed host-controlled task context; not derived from caller input at runtime.
_HOST_TASK = 'linear-1-plus-2x-v1'
_HOST_BASELINE_SHA256 = '13a507c28d29cce85240c71dc347be5260c23154a24e61449acd13ea3b03fa6c'
_MAX_REQUEST_BYTES = 4096


def verify_host_bound(request: bytes) -> HostVerdict:
    """Fail closed unless request is byte-for-byte authorized by host policy."""
    if type(request) is not bytes or len(request) > _MAX_REQUEST_BYTES:
        return HostVerdict('BLOCKED_INVALID_REQUEST', None, None)
    actual = sha256(request).hexdigest()
    if actual != _HOST_BASELINE_SHA256:
        return HostVerdict('BLOCKED_UNAUTHORIZED_BASELINE', actual, None)
    try:
        result = verify_registered_task(request, task_id=_HOST_TASK)
    except Exception:
        return HostVerdict('NOT_VERIFIED', actual, None)
    expected_registry_sha = fixture_digest(lookup(_HOST_TASK))
    if (result.status != 'FIXTURE_CONDITIONAL_PASS_NOT_PROMOTED'
            or result.task_id != _HOST_TASK
            or result.baseline_sha256 != actual
            or result.registry_record_sha256 != expected_registry_sha
            or result.correction is None):
        return HostVerdict('NOT_VERIFIED', actual, None)
    return HostVerdict('HOST_BOUND_FIXTURE_PASS_NOT_PROMOTED', actual,
                       expected_registry_sha)
