# URF-AI Local Research Console — Scientific CLI Bridge

Isolated research prototype. This console adds **four fixed, read-only scientific fixtures** to the previously Mac-tested mathematical question console. It does **not** accept user-provided executable code, arbitrary source paths, or unrestricted scientific payloads. The original Docker correction fixture remains unchanged.

## Files and execution

Place the archive in `~/Downloads`, extract to a fresh temporary directory and run `./launch_mac.sh`. The launcher confirms the exact Chronos HEAD `605aca6330c7b834c09eae77275763b8a374f864`, validates hashes of checkpoint `cli.py`, `scientific.py`, `science_sources.py`, assembles the package in an independent temporary directory, runs regression tests and launches the existing localhost token-protected GUI.

The GUI has a separate **Original scientific CLI** dropdown and button. Options are `integrate`, `compare`, `cycle-locality`, `source`. All payloads are fixed in `scientific_cli_bridge.py`. The host checks the exact integration answer, scalar comparison fields, the triangle fixture, or the SHA-256 and bytes of a fixed revision-pinned Git blob, respectively. The source result exposes its SHA-256 but does not display source text.

Scientific operations execute the trusted local Python CLI in a bounded subprocess (15-second wall limit; 8 KiB stdout/stderr per stream, up to 64 KiB for the pinned source), **not inside Docker**. The original registered polynomial correction remains Docker-backed. The local Python process is not a filesystem-isolated sandbox; never use untrusted repos, payloads, or plugins with this adapter.

## Verification status

113/113 existing and new tests pass in the isolated authoring environment, including 15 tests of the scientific bridge. **Full four-operation GUI-to-CLI execution on the user's Mac is NOT_RUN.** The scientific fixtures previously passed directly through the CLI on Mac. Production integration, authenticity of external scientific evidence, and any unrestricted theorem verification remain OPEN.

No Git writes, downloads, repository checkout changes, production promotion or automatic cleanup of prior research were performed.
