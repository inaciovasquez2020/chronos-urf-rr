"""Local-only URF-AI research GUI. No arbitrary question interpretation or code execution."""
from __future__ import annotations
import json
import re
import secrets
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
import docker_bridge
import scientific_cli_bridge
from exact_question import calculate, Unsupported

SUPPORTED_QUESTION = 'Verify the registered polynomial correction fixture'
MAX_REQUEST = 2048

def bare_equation(question):
    """An unprefixed equality is ambiguous between solving and universal identity."""
    q = question.strip()
    return ('=' in q and not re.match(r'^(?:solve|is|verify|check|evaluate|compute|what\s+is)\b', q, flags=re.I))

PAGE = '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'nonce-STYLE_NONCE'; script-src 'nonce-SCRIPT_NONCE'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'">
<title>URF-AI Research Console</title>
<style nonce="STYLE_NONCE">
:root{font-family:system-ui,-apple-system,sans-serif;color-scheme:dark;background:#10151c;color:#e7eefa}
body{max-width:810px;margin:48px auto;padding:0 20px}h1{letter-spacing:-.035em}p{line-height:1.6;color:#b6c5d5}
section{background:#19222e;border:1px solid #39495b;border-radius:14px;padding:24px;margin-top:20px}
label{display:block;font-weight:650;margin-bottom:10px}textarea{box-sizing:border-box;width:100%;min-height:105px;border:1px solid #596b80;border-radius:9px;padding:14px;background:#0c131c;color:#f7f9ff;font-size:16px}
button{background:#8db8ff;color:#07121e;border:0;border-radius:8px;padding:12px 18px;font-size:15px;font-weight:700;margin-top:15px;cursor:pointer}button:disabled{opacity:.5;cursor:wait}
pre{white-space:pre-wrap;word-wrap:break-word;background:#0d141e;border-radius:8px;padding:16px;color:#d5e7ff}
small{color:#a8b7c9} .intent{margin-top:12px;border-left:3px solid #8db8ff;padding:8px 14px;background:#101a28} .intent label{display:inline;font-weight:500;margin:0 16px 0 4px} .tag{color:#bde6ae;font-weight:700}
</style></head><body>
<header><small>LOCALHOST · RESEARCH ONLY · NOT PRODUCTION</small><h1>URF-AI Research Console</h1>
<p>Enter exact arithmetic, polynomial identities, substitution, or linear/quadratic equations for independent host-side checking. The registered Docker correction fixture remains available. No free-form AI inference is performed.</p></header>
<section><label for="question">Research question</label><textarea id="question">Verify the registered polynomial correction fixture</textarea>
<p><small><strong>How to ask:</strong> Calculate: <code>2 + 2</code> (4). Evaluate: <code>Evaluate x^2 + 3*x at x = 5</code> (40). Solve: <code>Solve x^2 - 4 = 0</code> (roots -2, 2). Verify an identity: <code>Is x^2 - 4 = (x-2)*(x+2)?</code> (true for every x). Use * for multiplication and ^ for powers.</small></p>
<p><small><strong>Important:</strong> A bare equality such as <code>x^2 - 4 = 0</code> is ambiguous. Choose whether to solve for x or check that it is true for all x. A false identity is not the same as an equation without solutions.</small></p>
<div id="intent" class="intent" hidden><strong>What do you want to do?</strong><p><label><input type="radio" name="intent" value="solve"> Solve for x</label><label><input type="radio" name="intent" value="identity"> Verify identity for all x</label></p><small>No operation is selected by default.</small></div>
<button id="run">Run bounded verification</button>
<div class="intent" style="margin-top:24px"><label for="science">Original scientific CLI (fixed registered fixtures)</label>
<select id="science" style="padding:10px;background:#0c131c;color:#f7f9ff">
<option value="integrate">Integrate x on [0,1]</option>
<option value="compare">Compare 1/2 to 1/2</option>
<option value="cycle-locality">Triangle cycle locality, radius 1</option>
<option value="source">Verify pinned source digest</option></select>
<button id="run-science">Run scientific CLI fixture</button>
<p><small>Fixed tests only. Source reads are pinned; no arbitrary repository or code execution.</small></p></div></section>
<section aria-live="polite"><label>Verification output</label><pre id="output">NOT_RUN</pre>
<p><small>Results are fixture-relative. A passing result does not authenticate external evidence or verify arbitrary mathematical claims.</small></p></section>
<script nonce="SCRIPT_NONCE">
'use strict';
const b=document.getElementById('run'),q=document.getElementById('question'),out=document.getElementById('output'),intent=document.getElementById('intent');
// Presentation only: retain original machine status and complete receipt fields.
function humanFinding(j){
 if(j.status==='PROVED' && j.detail==='NO_REAL_ROOTS')return 'NO REAL SOLUTIONS';
 if(j.status==='PROVED' && j.detail==='NO_RATIONAL_OR_REAL_SOLUTIONS')return 'NO REAL SOLUTIONS';
 if(j.status==='PROVED' && j.detail==='ALL_RATIONAL_VALUES_SATISFY')return 'ALL RATIONAL VALUES SATISFY THE EQUATION';
 if(j.status==='PROVED' && j.detail==='EXACT_LINEAR_ROOT')return 'EXACT LINEAR SOLUTION';
 if(j.status==='PROVED' && (j.detail==='EXACT_QUADRATIC_RATIONAL_ROOTS'||j.detail==='EXACT_QUADRATIC_RADICAL_ROOTS'))return 'EXACT QUADRATIC SOLUTIONS';
 if(j.status==='PROVED' && j.detail==='EXACT_POLYNOMIAL_IDENTITY')return 'IDENTITY HOLDS FOR ALL x';
 if(j.status==='REFUTED' && j.detail==='POLYNOMIALS_DIFFER')return 'IDENTITY FALSE';
 if(j.status==='COMPUTATION_PASS')return 'REGISTERED COMPUTATION PASSED';
 if(j.status==='UNSUPPORTED')return 'INPUT UNSUPPORTED';
 if(j.status==='INCOMPLETE')return 'VERIFICATION INCOMPLETE';
 return 'NO HUMAN VERDICT AVAILABLE';
}

function needsChoice(s){return s.includes('=')&&!/^(solve|is|verify|check|evaluate|compute|what\\s+is)\\b/i.test(s.trim());}
function updateIntent(){const needed=needsChoice(q.value);intent.hidden=!needed;if(!needed){for(const c of intent.querySelectorAll('input'))c.checked=false;}}
q.addEventListener('input',updateIntent);updateIntent();
b.addEventListener('click',async()=>{
 const choice=needsChoice(q.value)?intent.querySelector('input:checked')?.value:null;
 if(needsChoice(q.value)&&!choice){out.textContent='NEEDS_INTENT: Choose Solve for x or Verify identity for all x.';return;}
 b.disabled=true;out.textContent='RUNNING — bounded checker';
 try{
  const r=await fetch('run',{method:'POST',headers:{'Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE'},
   body:JSON.stringify(choice?{question:q.value,intent:choice}:{question:q.value})});
  const j=await r.json();out.textContent='FINDING: '+humanFinding(j)+'\\nSTATUS: '+j.status+'\\nDETAIL: '+j.detail+'\\nRESULT: '+(j.answer??j.roots?.join(', ')??j.solution_set??'—')+(j.counterexample?'\\nCOUNTEREXAMPLE: x='+j.counterexample.x+', left='+j.counterexample.left+', right='+j.counterexample.right:'')+'\\nPROMOTION: NOT_PERFORMED';
 }catch(e){out.textContent='INCOMPLETE_TRANSPORT';}finally{b.disabled=false;}
});

document.getElementById('run-science').addEventListener('click',async()=>{
 const b2=document.getElementById('run-science');b2.disabled=true;out.textContent='RUNNING — scientific CLI fixture';
 try {
  const r=await fetch('run',{method:'POST',headers:{'Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE'},
   body:JSON.stringify({science_operation:document.getElementById('science').value})});
  const j=await r.json();
  out.textContent='FINDING: '+humanFinding(j)+'\\nSTATUS: '+j.status+'\\nDETAIL: '+j.detail+'\\nRESULT: '+(j.answer??'—')+'\\nPROMOTION: NOT_PERFORMED';
 }catch(e){out.textContent='INCOMPLETE_TRANSPORT';}finally{b2.disabled=false;}
});
</script></body></html>'''


def strict_json(raw):
    def reject_duplicates(pairs):
        d = {}
        for k, v in pairs:
            if k in d:
                raise ValueError('DUPLICATE_KEY')
            d[k] = v
        return d
    return json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=reject_duplicates)


def make_handler(token, port, runner=None, science_runner=None):
    if runner is None:
        runner = docker_bridge.run
    if science_runner is None:
        science_runner = scientific_cli_bridge.run
    # A per-server token is generated on launch; restrict all handlers to this path.
    prefix = '/' + token + '/'
    host = '127.0.0.1:' + str(port)
    style_nonce = secrets.token_urlsafe(18)
    script_nonce = secrets.token_urlsafe(18)
    page = PAGE.replace('STYLE_NONCE', style_nonce).replace('SCRIPT_NONCE', script_nonce).encode('utf-8')

    class Handler(BaseHTTPRequestHandler):
        server_version = 'URFResearchConsole/0.1'
        sys_version = ''
        def log_message(self, fmt, *args):
            # Do not print the secret path or user-provided questions in logs.
            pass
        def reply(self, status, payload, content_type='application/json; charset=utf-8'):
            data = payload if isinstance(payload, bytes) else json.dumps(payload, separators=(',', ':')).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        def authorized(self, allow_navigation=False):
            if self.headers.get('Host') != host:
                return False
            origin = self.headers.get('Origin')
            if origin is not None and origin != 'http://' + host:
                return False
            site = self.headers.get('Sec-Fetch-Site')
            if site not in ((None, 'same-origin', 'none') if allow_navigation else (None, 'same-origin')):
                return False
            return True
        def do_GET(self):
            if not self.authorized(allow_navigation=True) or self.path != prefix:
                self.reply(403, {'status':'BLOCKED','detail':'ACCESS_DENIED'})
                return
            self.reply(200, page, 'text/html; charset=utf-8')
        def do_POST(self):
            if not self.authorized() or self.path != prefix + 'run':
                self.reply(403, {'status':'BLOCKED','detail':'ACCESS_DENIED'})
                return
            if self.headers.get('X-URF-Confirm') != 'RUN_REGISTERED_FIXTURE' or self.headers.get('Content-Type') != 'application/json':
                self.reply(403, {'status':'BLOCKED','detail':'CONFIRMATION_REQUIRED'})
                return
            try:
                length = int(self.headers.get('Content-Length', '-1'))
            except ValueError:
                length = -1
            if length < 1 or length > MAX_REQUEST:
                self.reply(413, {'status':'BLOCKED','detail':'INPUT_LIMIT'})
                return
            try:
                self.connection.settimeout(5)
                data = strict_json(self.rfile.read(length))
            except (ValueError, UnicodeError, OSError):
                self.reply(400, {'status':'BLOCKED','detail':'BAD_JSON'})
                return
            if type(data) is dict and set(data)=={'science_operation'}:
                operation=data['science_operation']
                if type(operation) is not str or operation not in ('integrate','compare','cycle-locality','source'):
                    self.reply(422, {'status':'UNSUPPORTED','detail':'UNREGISTERED_SCIENCE_OPERATION'})
                    return
                try:
                    verdict=science_runner(operation)
                    if type(verdict) is not dict or verdict.get('status') not in ('COMPUTATION_PASS','INCOMPLETE'):
                        raise ValueError('UNEXPECTED_SCIENCE_VERDICT')
                    self.reply(200,verdict)
                except Exception:
                    self.reply(200, {'status':'INCOMPLETE','detail':'SCIENTIFIC_BRIDGE_ERROR'})
                return
            if type(data) is not dict or set(data) not in ({'question'}, {'question','intent'}) or type(data['question']) is not str or len(data['question']) > 300 or ('intent' in data and (type(data['intent']) is not str or data['intent'] not in ('solve','identity'))):
                self.reply(400, {'status':'BLOCKED','detail':'INPUT_SCHEMA'})
                return
            question = data['question'].strip()
            intent_value = data.get('intent')
            if bare_equation(question):
                if intent_value is None:
                    self.reply(422, {'status':'NEEDS_INTENT','detail':'CHOOSE_SOLVE_OR_IDENTITY'})
                    return
                question = ('Solve ' if intent_value == 'solve' else 'Is ') + question
            elif intent_value is not None:
                self.reply(400, {'status':'BLOCKED','detail':'INTENT_NOT_APPLICABLE'})
                return
            if question != SUPPORTED_QUESTION:
                try:
                    answer = calculate(question)
                except Unsupported as exc:
                    self.reply(422, {'status':'UNSUPPORTED','detail':str(exc)[:100]})
                    return
                self.reply(200, answer)
                return
            try:
                result = runner()
            except Exception:
                self.reply(200, {'status':'INCOMPLETE','detail':'WORKER_ERROR'})
                return
            if result == 'DOCKER_FIXTURE_COMPUTATION_PASS_NOT_PROMOTED':
                self.reply(200, {'status':'COMPUTATION_PASS','detail':result})
            else:
                self.reply(200, {'status':'INCOMPLETE','detail':str(result)[:150]})
    return Handler


def launch(open_browser=True):
    # Port allocated by kernel. Handler installed only after allocation.
    server = HTTPServer(('127.0.0.1', 0), BaseHTTPRequestHandler)
    port = server.server_address[1]
    token = secrets.token_urlsafe(24)
    server.RequestHandlerClass = make_handler(token, port)
    url = 'http://127.0.0.1:' + str(port) + '/' + token + '/'
    print('LOCAL_RESEARCH_CONSOLE := ' + url, flush=True)
    print('RUN_MODE := EXACT_ARITHMETIC_EVALUATION_RATIONAL_SOLVER_AND_DOCKER_FIXTURE', flush=True)
    print('PRODUCTION_PROMOTION := NOT_PERFORMED', flush=True)
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    launch()
