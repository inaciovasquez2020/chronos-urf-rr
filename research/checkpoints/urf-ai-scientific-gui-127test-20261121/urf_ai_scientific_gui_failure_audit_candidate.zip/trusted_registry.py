"""Code-pinned scientific fixtures, provisioned outside correction requests.

These are test specifications, NOT authenticated external mathematical evidence.
Updating any record requires a reviewed release of this trusted module.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import json
from types import MappingProxyType

@dataclass(frozen=True)
class Fixture:
    task_id: str
    reference_side: str
    coefficients: tuple[str, ...]
    values: tuple[str, ...]
    source_label: str

# These records are deliberately simple, fully checkable research fixtures.
# Neither the candidate nor caller supplies these values or their digest.
_FIXTURES = MappingProxyType({
    'linear-1-plus-2x-v1': Fixture(
        'linear-1-plus-2x-v1', 'left', ('1', '2'), ('1', '3'),
        'RESEARCH_FIXTURE_LINEAR_V1'),
    'quadratic-square-plus-2x-plus-1-v1': Fixture(
        'quadratic-square-plus-2x-plus-1-v1', 'right',
        ('1', '2', '1'), ('1', '4', '9'), 'RESEARCH_FIXTURE_QUADRATIC_V1'),
})

def lookup(task_id: str) -> Fixture:
    if type(task_id) is not str or task_id not in _FIXTURES:
        raise ValueError('UNKNOWN_TRUSTED_TASK')
    return _FIXTURES[task_id]

def fixture_digest(f: Fixture) -> str:
    payload = {'task_id': f.task_id, 'reference_side': f.reference_side,
               'coefficients': list(f.coefficients), 'values': list(f.values),
               'source_label': f.source_label}
    return sha256(json.dumps(payload, sort_keys=True,
                             separators=(',', ':')).encode('utf-8')).hexdigest()
