"""Adversarial exact counterexamples for the polynomial-identity checker."""
from fractions import Fraction
import unittest
from exact_question import calculate, polynomial, exact_eval

class CounterexampleTests(unittest.TestCase):
    def verify_witness(self, question):
        result = calculate(question)
        self.assertEqual(result['status'], 'REFUTED')
        witness = result['counterexample']
        x = Fraction(witness['x'])
        self.assertEqual(witness['left'], str(exact_eval(polynomial(question.split('=',1)[0].strip()), x)))
        self.assertEqual(witness['right'], str(exact_eval(polynomial(question.split('=',1)[1].strip()), x)))
        self.assertNotEqual(witness['left'], witness['right'])
        return witness

    def test_simple_counterexample(self):
        self.assertEqual(self.verify_witness('x^2 - 4 = 0'), {'x':'0','left':'-4','right':'0'})

    def test_identity_has_no_counterexample(self):
        r=calculate('Is x^2 - 4 = (x-2)*(x+2)?')
        self.assertEqual(r['status'], 'PROVED')
        self.assertNotIn('counterexample', r)

    def test_degree_twelve_guarantees_witness(self):
        roots=[0,1,-1,2,-2,3,-3,4,-4,5,-5,6]
        expr='*'.join(f'(x-({v}))' for v in roots)
        witness=self.verify_witness(expr+' = 0')
        self.assertEqual(witness['x'], '-6')

    def test_fractional_counterexample(self):
        witness=self.verify_witness('x/3 + 1/7 = x/3 + 2/7')
        self.assertEqual((witness['left'],witness['right']), ('1/7','2/7'))

    def test_degree_over_limit_rejected(self):
        from exact_question import Unsupported
        with self.assertRaises(Unsupported):
            calculate('x^13 = 0')

    def test_no_solve_semantic_change(self):
        self.assertEqual(calculate('Solve x^2 - 4 = 0')['roots'],['-2','2'])

if __name__=='__main__': unittest.main()
