import http.client
import json
import threading
import unittest
from http.server import HTTPServer
from research_console import make_handler

class IntentTests(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        self.s=HTTPServer(('127.0.0.1',0),make_handler('token',0,lambda:self.calls.append(1)))
        self.port=self.s.server_address[1]
        self.s.RequestHandlerClass=make_handler('token',self.port,lambda:self.calls.append(1))
        self.thread=threading.Thread(target=self.s.serve_forever,daemon=True);self.thread.start()
    def tearDown(self):
        self.s.shutdown();self.s.server_close();self.thread.join(timeout=2)
    def req(self, question, intent=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        payload={'question':question}
        if intent is not None:payload['intent']=intent
        conn.request('POST','/token/run',json.dumps(payload),headers={'Host':f'127.0.0.1:{self.port}','Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE'})
        res=conn.getresponse();code=res.status;body=json.loads(res.read());conn.close();return code,body
    def test_ambiguous_default_requires_choice(self):
        c,b=self.req('x^2 - 4 = 0');self.assertEqual((c,b['status'],b['detail']),(422,'NEEDS_INTENT','CHOOSE_SOLVE_OR_IDENTITY'))
    def test_explicit_solve(self):
        c,b=self.req('x^2 - 4 = 0','solve');self.assertEqual(c,200);self.assertEqual(b['roots'],['-2','2'])
    def test_explicit_identity(self):
        c,b=self.req('x^2 - 4 = 0','identity');self.assertEqual(c,200);self.assertEqual(b['status'],'REFUTED')
    def test_unchanged_true_identity(self):
        c,b=self.req('Is x^2 - 4 = (x-2)*(x+2)?');self.assertEqual(c,200);self.assertEqual(b['status'],'PROVED')
    def test_invalid_intent(self):
        c,b=self.req('x^2 - 4 = 0','execute');self.assertEqual(c,400);self.assertEqual(b['status'],'BLOCKED')
    def test_intent_not_applicable(self):
        c,b=self.req('2 + 2','solve');self.assertEqual(c,400);self.assertEqual(b['detail'],'INTENT_NOT_APPLICABLE')
    def test_prefixed_solve_no_choice(self):
        c,b=self.req('Solve x^2 - 4 = 0');self.assertEqual(c,200);self.assertEqual(b['roots'],['-2','2'])
    def test_docker_no_choice(self):
        c,b=self.req('Verify the registered polynomial correction fixture');self.assertEqual(c,200);self.assertEqual(b['status'],'INCOMPLETE');self.assertEqual(len(self.calls),1)
    def test_gui_contains_disclaimer_and_choice(self):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        conn.request('GET','/token/',headers={'Host':f'127.0.0.1:{self.port}'})
        res=conn.getresponse();html=res.read().decode();conn.close()
        self.assertEqual(res.status,200);self.assertIn('A bare equality',html);self.assertIn('name="intent" value="solve"',html);self.assertIn('No operation is selected by default.',html);self.assertIn(r'what\s+is)\b/i.test',html);self.assertNotIn('\x08',html)
    def test_unsupported_and_malformed_fail_closed(self):
        c,b=self.req('Prove everything');self.assertEqual(c,422);self.assertEqual(b['status'],'UNSUPPORTED');self.assertEqual(self.calls,[])
if __name__=='__main__':unittest.main()
