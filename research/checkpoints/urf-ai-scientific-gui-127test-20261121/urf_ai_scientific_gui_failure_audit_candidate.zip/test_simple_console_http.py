import http.client
import json
import threading
import unittest
from http.server import HTTPServer
from research_console import make_handler

class SimpleConsoleHttpTests(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        def worker():
            self.calls.append('docker')
            return 'DOCKER_FIXTURE_COMPUTATION_PASS_NOT_PROMOTED'
        self.server=HTTPServer(('127.0.0.1',0),make_handler('test-key',0,worker))
        self.port=self.server.server_address[1]
        self.server.RequestHandlerClass=make_handler('test-key',self.port,worker)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=2)
    def request(self,question,**headers):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        h={'Host':f'127.0.0.1:{self.port}','Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE', **headers}
        c.request('POST','/test-key/run',json.dumps({'question':question}),h)
        r=c.getresponse(); status=r.status; data=json.loads(r.read());c.close()
        return status,data
    def test_arithmetic_uses_no_docker(self):
        code,body=self.request('2 + 2')
        self.assertEqual(code,200);self.assertEqual(body['answer'],'4');self.assertEqual(self.calls,[])
    def test_identity_uses_no_docker(self):
        code,body=self.request('Is x² - 4 = (x-2)*(x+2)?')
        self.assertEqual(code,200);self.assertEqual(body['status'],'PROVED');self.assertEqual(self.calls,[])
    def test_unsupported_does_not_run(self):
        code,body=self.request('Please prove a new theorem')
        self.assertEqual(code,422);self.assertEqual(body['status'],'UNSUPPORTED');self.assertEqual(self.calls,[])
    def test_evaluation_uses_no_docker(self):
        code,body=self.request('Evaluate x^2 + 3*x at x = 5')
        self.assertEqual(code,200);self.assertEqual(body['answer'],'40');self.assertEqual(self.calls,[])
    def test_equation_uses_no_docker(self):
        code,body=self.request('Solve x^2 - 4 = 0')
        self.assertEqual(code,200);self.assertEqual(body['roots'],['-2','2']);self.assertEqual(self.calls,[])
    def test_irrational_solution_exact_radical(self):
        code,body=self.request('Solve x^2 - 2 = 0')
        self.assertEqual(code,200)
        self.assertEqual(body['status'],'PROVED')
        self.assertEqual(body['detail'],'EXACT_QUADRATIC_RADICAL_ROOTS')
        self.assertEqual(body['representation'],'EXACT_SYMBOLIC_NOT_APPROXIMATE')
        self.assertEqual(self.calls,[])
    def test_cross_site_blocks_exact_math(self):
        code,body=self.request('2+2',**{'Sec-Fetch-Site':'cross-site'})
        self.assertEqual(code,403);self.assertEqual(self.calls,[])
    def test_docker_path_preserved(self):
        code,body=self.request('Verify the registered polynomial correction fixture')
        self.assertEqual(code,200);self.assertEqual(body['status'],'COMPUTATION_PASS');self.assertEqual(self.calls,['docker'])
if __name__=='__main__': unittest.main()
