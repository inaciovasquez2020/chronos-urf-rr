"""Run the pinned fixture in Docker with exact host-side verification.

This is a research demonstration. It does not authenticate external evidence
or provide an untrusted-code sandbox. No host research paths are mounted.
"""
from __future__ import annotations
import hashlib, json, os, pathlib, selectors, signal, subprocess, sys, tempfile, time, uuid
from host_bound_adapter import verify_host_bound
from host_math_check import check_worker_witness

IMAGE='ghcr.io/inaciovasquez2020/urf-sg-verifier:sha-40eade5'
EXPECTED_IMAGE='sha256:fa6269e572095db0e631e87e04950de3715d3825730d1ce716720cf98fabc53c'
EXPECTED_BASELINE='13a507c28d29cce85240c71dc347be5260c23154a24e61449acd13ea3b03fa6c'
MAX_OUTPUT=8192
TIMEOUT=30
FILES=['worker.py','baseline.json','host_bound_adapter.py','registry_backtracking.py',
       'trusted_registry.py','reference_evidence.py','scientific_adapter.py',
       'declarative_backtracking.py','deterministic_generator.py','controller.py']

def strict_json(data:bytes):
    def reject_duplicates(pairs):
        result={}
        for key,value in pairs:
            if key in result: raise ValueError('DUPLICATE_KEY')
            result[key]=value
        return result
    return json.loads(data.decode('utf-8','strict'),object_pairs_hook=reject_duplicates)

def check_receipt(data:bytes, expected):
    if len(data)>MAX_OUTPUT: raise ValueError('OUTPUT_LIMIT')
    result=strict_json(data)
    if type(result) is not dict or set(result)!={'status','baseline_sha256','registered_evidence_sha256','input_sha256','corrected_coefficients'}:
        raise ValueError('RECEIPT_SCHEMA')
    if result != expected: raise ValueError('RECEIPT_MISMATCH')
    return True

def build_command(directory:str, name:str):
    # Container has read-only root; only disposable package tree mounted read-only.
    return ['docker','run','--rm','--pull=never','--name',name,
       '--memory=128m','--memory-swap=128m','--cpus=1','--pids-limit=32',
       '--read-only','--network=none','--cap-drop=ALL',
       '--security-opt=no-new-privileges','--user=65534:65534',
       '--mount','type=bind,src='+directory+',dst=/input,readonly',
       '--workdir=/input','--entrypoint=python3',IMAGE,'-B','/input/worker.py']

def limited_run(argv, timeout, max_output=MAX_OUTPUT):
    """Capture at most MAX_OUTPUT bytes per stream, including on failures.

    Any subprocess that exceeds either bound is terminated immediately.
    No production command should inherit these pipes or fork long-lived daemons.
    """
    p = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         start_new_session=True)
    sel = selectors.DefaultSelector()
    out, err = bytearray(), bytearray()
    deadline = time.monotonic() + timeout
    try:
        for stream, destination in ((p.stdout, out), (p.stderr, err)):
            os.set_blocking(stream.fileno(), False)
            sel.register(stream, selectors.EVENT_READ, destination)
        while sel.get_map():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(argv, timeout)
            events = sel.select(min(0.1, remaining))
            for key, _ in events:
                chunk = os.read(key.fileobj.fileno(), max_output + 1)
                if not chunk:
                    sel.unregister(key.fileobj)
                    continue
                target = key.data
                if len(target) + len(chunk) > max_output:
                    raise ValueError('OUTPUT_LIMIT')
                target.extend(chunk)
        remaining = deadline - time.monotonic()
        if remaining <= 0 and p.poll() is None:
            raise subprocess.TimeoutExpired(argv, timeout)
        try:
            code = p.wait(timeout=max(0, remaining))
        except subprocess.TimeoutExpired:
            raise subprocess.TimeoutExpired(argv, timeout)
        return code, bytes(out), bytes(err)
    except BaseException:
        if p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        p.wait()
        raise
    finally:
        sel.close()
        p.stdout.close()
        p.stderr.close()


def stop_own_container(name):
    """Best-effort cleanup of only this invocation's disposable container."""
    try:
        r = subprocess.run(['docker','stop','--time','1',name],
                           capture_output=True, timeout=5)
        return r.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False

def run():
    root=pathlib.Path(__file__).resolve().parent
    base=(root/'baseline.json').read_bytes()
    if hashlib.sha256(base).hexdigest()!=EXPECTED_BASELINE:
        return 'BLOCKED_BASELINE_PIN'
    expected_verdict=verify_host_bound(base)
    if expected_verdict.status!='HOST_BOUND_FIXTURE_PASS_NOT_PROMOTED':
        return 'BLOCKED_HOST_POLICY'
    expected={'status':expected_verdict.status,'baseline_sha256':expected_verdict.baseline_sha256,
              'registered_evidence_sha256':expected_verdict.registered_evidence_sha256,
              'input_sha256':hashlib.sha256(base).hexdigest(),
              'corrected_coefficients':['1','2']}
    try:
        r=subprocess.run(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],
                         capture_output=True,text=True,timeout=8)
    except (OSError,subprocess.TimeoutExpired):return 'INCOMPLETE_DOCKER_UNAVAILABLE'
    if r.returncode!=0 or r.stdout.strip()!=EXPECTED_IMAGE:
        return 'BLOCKED_IMAGE_PIN'
    with tempfile.TemporaryDirectory(prefix='urf-ai-docker-bridge-') as temp:
        stage=pathlib.Path(temp)
        for filename in FILES:
            content=(root/filename).read_bytes()
            (stage/filename).write_bytes(content)
            (stage/filename).chmod(0o644)
        stage.chmod(0o755)
        name='urf-ai-research-bridge-'+uuid.uuid4().hex[:12]
        try:
            code,out,err=limited_run(build_command(str(stage),name),TIMEOUT)
        except subprocess.TimeoutExpired:
            stop_own_container(name)
            return 'INCOMPLETE_TIMEOUT'
        except ValueError:
            stop_own_container(name)
            return 'INCOMPLETE_OUTPUT_LIMIT'
        except OSError:
            stop_own_container(name)
            return 'INCOMPLETE_SPAWN'
        if code!=0:
            return 'INCOMPLETE_CONTAINER_NONZERO_'+str(code)
        try:
            check_receipt(out.strip(),expected)
            check_worker_witness(base,strict_json(out.strip()))
        except (ValueError,UnicodeError,TypeError):return 'NOT_VERIFIED_RECEIPT'
        return 'DOCKER_FIXTURE_COMPUTATION_PASS_NOT_PROMOTED'

if __name__=='__main__':
    result=run()
    print('DOCKER_BRIDGE_RESULT :=',result)
    print('AUTHENTICATION := NOT_ESTABLISHED')
    print('PRODUCTION_PROMOTION := NOT_PERFORMED')
    sys.exit(0 if result=='DOCKER_FIXTURE_COMPUTATION_PASS_NOT_PROMOTED' else 1)
