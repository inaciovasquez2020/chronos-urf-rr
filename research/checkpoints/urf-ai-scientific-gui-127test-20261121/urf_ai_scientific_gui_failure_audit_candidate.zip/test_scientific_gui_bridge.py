import http.client
import json
import threading
import unittest
from http.server import HTTPServer
from unittest.mock import patch
import scientific_cli_bridge as bridge
from research_console import make_handler

class ScientificReceiptTests(unittest.TestCase):
    def test_integration_exact(self):
        r=bridge.verify('integrate',{'status':'COMPUTATION_PASS','value':'1/2'})
        self.assertEqual(r['answer'],'1/2')
    def test_forged_status_rejected(self):
        with self.assertRaises(ValueError):
            bridge.verify('integrate',{'status':'COMPUTATION_PASS','value':'1/3'})
    def test_comparison_exact(self):
        d={'published':'1/2','candidate':'1/2','difference':'0','discrepancy':False,'status':'COMPUTATION_PASS','published_error_confirmed':False}
        self.assertEqual(bridge.verify('compare',d)['status'],'COMPUTATION_PASS')
        d['discrepancy']=True
        with self.assertRaises(ValueError): bridge.verify('compare',d)
    def test_triangle_exact(self):
        d={'equivalent':True,'global_dimension':1,'local_span_dimension':1,'states_checked':8,'status':'COMPUTATION_PASS'}
        self.assertEqual(bridge.verify('cycle-locality',d)['status'],'COMPUTATION_PASS')
        d['global_dimension']=True
        with self.assertRaises(ValueError): bridge.verify('cycle-locality',d)
    def test_source_provenance(self):
        import hashlib
        b=b'known file bytes'; repo='/test/repo'
        d={'path':bridge.SOURCE_PATH,'revision':bridge.REV,'repository':repo,'sha256':hashlib.sha256(b).hexdigest(),'source':b.decode()}
        self.assertEqual(bridge.verify('source',d,b,repo)['status'],'COMPUTATION_PASS')
        d['source']='tampered'
        with self.assertRaises(ValueError): bridge.verify('source',d,b,repo)
    def test_duplicate_receipt(self):
        with self.assertRaises(ValueError): bridge.decode(b'{"status":"COMPUTATION_PASS","status":"INCOMPLETE"}')
    def test_no_stage_fail_closed(self):
        with patch.dict('os.environ', {'URF_SCIENCE_STAGE':'','URF_SCIENCE_REPO':''}):
            self.assertEqual(bridge.run('integrate')['status'],'INCOMPLETE')
    def test_unregistered_op(self):
        self.assertEqual(bridge.run('shell')['status'],'UNSUPPORTED')

class ScienceHttpTests(unittest.TestCase):
    def setUp(self):
        self.calls=[]
        def fake(op):
            self.calls.append(op)
            return {'status':'COMPUTATION_PASS','detail':'TEST','answer':'ok'}
        self.server=HTTPServer(('127.0.0.1',0),make_handler('science-test',0,lambda:'INCOMPLETE',fake))
        self.port=self.server.server_address[1]
        self.server.RequestHandlerClass=make_handler('science-test',self.port,lambda:'INCOMPLETE',fake)
        self.t=threading.Thread(target=self.server.serve_forever,daemon=True);self.t.start()
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.t.join(timeout=2)
    def request(self, data, path='/science-test/run', headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        h={'Host':f'127.0.0.1:{self.port}','Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE'}
        if headers:h.update(headers)
        c.request('POST',path,json.dumps(data),h)
        r=c.getresponse();status=r.status;body=json.loads(r.read());c.close()
        return status,body
    def test_success_dispatch(self):
        status,r=self.request({'science_operation':'integrate'})
        self.assertEqual(status,200);self.assertEqual(r['status'],'COMPUTATION_PASS');self.assertEqual(self.calls,['integrate'])
    def test_unknown_operation_rejected(self):
        status,r=self.request({'science_operation':'shell'})
        self.assertEqual(status,422);self.assertEqual(self.calls,[])
    def test_extra_payload_rejected(self):
        status,r=self.request({'science_operation':'source','repo':'/etc'})
        self.assertEqual(status,400);self.assertEqual(self.calls,[])
    def test_cross_site_rejected(self):
        status,r=self.request({'science_operation':'integrate'},headers={'Sec-Fetch-Site':'cross-site'})
        self.assertEqual(status,403);self.assertEqual(self.calls,[])
    def test_bad_origin_rejected(self):
        status,r=self.request({'science_operation':'integrate'},headers={'Origin':'https://example.com'})
        self.assertEqual(status,403);self.assertEqual(self.calls,[])
    def test_bad_token_rejected(self):
        status,r=self.request({'science_operation':'integrate'},path='/run')
        self.assertEqual(status,403);self.assertEqual(self.calls,[])
    def test_failed_worker_closed(self):
        self.server.RequestHandlerClass=make_handler('science-test',self.port,lambda:None,lambda op:{'status':'PROVED'})
        status,r=self.request({'science_operation':'integrate'})
        self.assertEqual(r['status'],'INCOMPLETE')

if __name__=='__main__':unittest.main()
