# URF-AI scientific GUI failure propagation audit

Status: `COMPUTATION_PASS` for bounded isolated tests, NOT production approved.

Base: `urf_ai_scientific_gui_integrated_candidate.zip` (existing artifact).
Additional test: `test_scientific_failure_paths.py` (14 cases).

Observed in isolated Python runtime: `127 tests in 21.274s: OK`.
Tests mock scientific subprocess receipts; they do **not** execute the original Chronos scientific CLI on the Mac or establish complete OS sandboxing. They inspect the actual package's `scientific_cli_bridge.run`/`verify` functions and preserve the existing tests.

14 cases: normal integration receipt; nonzero subprocess error; timeout; output limit; missing executable; malformed JSON; duplicate JSON keys; false success with wrong exact answer; forged PROVED status; altered Git revision; contaminated GIT_DIR; wrong triangle local dimension; mismatch between pinned source receipt and Git blob; unregistered operation does not spawn.

Important trust boundaries still OPEN:
* The triangle `local_span_dimension=1` is a fixed fixture assertion; the host does not independently implement arbitrary graph locality.
* The source comparison is repository-relative, not independent repository authenticity.
* Existing source scripts inherit a host environment (including PATH) that is not fully attested.
* Tests do not prove no orphan subprocesses after arbitrary process-tree behavior or durable resource isolation.
* Mac replay of this new test suite is NOT_RUN.

No Chronos checkout, URF-Core checkout, checkpoint, or installed GUI modified. No commit/push/merge.
