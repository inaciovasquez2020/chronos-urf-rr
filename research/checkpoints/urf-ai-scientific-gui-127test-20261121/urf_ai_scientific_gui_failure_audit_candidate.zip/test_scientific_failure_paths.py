"""Adversarial failure propagation for the isolated URF-AI scientific bridge."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import scientific_cli_bridge as bridge

GOOD = {
    'integrate': {'status':'COMPUTATION_PASS','value':'1/2'},
    'compare': {'published':'1/2','candidate':'1/2','difference':'0','discrepancy':False,
                'status':'COMPUTATION_PASS','published_error_confirmed':False},
    'cycle-locality': {'equivalent':True,'global_dimension':1,'local_span_dimension':1,
                       'states_checked':8,'status':'COMPUTATION_PASS'}
}

class FailurePropagation(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        (root/'stage'/'research_agent_toolkit').mkdir(parents=True)
        (root/'stage'/'research_agent_toolkit'/'scientific.py').write_text('')
        (root/'repo'/'.git').mkdir(parents=True)
        self.repo=root/'repo'; self.stage=root/'stage'
        e=patch.dict(os.environ,{'URF_SCIENCE_STAGE':str(self.stage),
                                  'URF_SCIENCE_REPO':str(self.repo)},clear=False)
        e.start(); self.addCleanup(e.stop)
        for k in ('GIT_DIR','GIT_WORK_TREE'):
            p=patch.dict(os.environ,{k:''});p.start();self.addCleanup(p.stop)

    def patched_run(self,operation,second):
        calls=[]
        def fake(cmd, **kw):
            calls.append(cmd)
            if len(calls)==1:
                return (bridge.REV+'\n').encode()
            return second(cmd, **kw)
        with patch.object(bridge,'_run_checked',side_effect=fake):
            return bridge.run(operation)

    def test_nominal_registered_integration(self):
        r=self.patched_run('integrate',lambda cmd,**kw: json.dumps(GOOD['integrate']).encode())
        self.assertEqual(r['status'],'COMPUTATION_PASS')

    def test_nonzero_exit(self):
        def failure(cmd,**kw): raise ValueError('NONZERO_EXIT')
        self.assertEqual(self.patched_run('integrate',failure)['status'],'INCOMPLETE')

    def test_timeout(self):
        def failure(cmd,**kw): raise subprocess.TimeoutExpired(cmd, 15)
        r=self.patched_run('integrate',failure)
        self.assertEqual((r['status'],r['detail']),('INCOMPLETE','SCIENTIFIC_CLI_TIMEOUT'))

    def test_output_over_budget(self):
        def failure(cmd,**kw): raise ValueError('OUTPUT_LIMIT')
        self.assertEqual(self.patched_run('integrate',failure)['status'],'INCOMPLETE')

    def test_missing_executable(self):
        def failure(cmd,**kw): raise FileNotFoundError('python missing')
        self.assertEqual(self.patched_run('integrate',failure)['status'],'INCOMPLETE')

    def test_bad_json(self):
        self.assertEqual(self.patched_run('integrate',lambda cmd,**kw:b'{')['status'],'INCOMPLETE')

    def test_duplicate_keys(self):
        b=b'{"status":"COMPUTATION_PASS","status":"INCOMPLETE","value":"1/2"}'
        self.assertEqual(self.patched_run('integrate',lambda cmd,**kw:b)['status'],'INCOMPLETE')

    def test_false_success_with_wrong_answer(self):
        b=b'{"status":"COMPUTATION_PASS","value":"1/3"}'
        self.assertEqual(self.patched_run('integrate',lambda cmd,**kw:b)['status'],'INCOMPLETE')

    def test_foreign_receipt_status(self):
        b=b'{"status":"PROVED","value":"1/2"}'
        self.assertEqual(self.patched_run('integrate',lambda cmd,**kw:b)['status'],'INCOMPLETE')

    def test_rejection_when_git_revision_changes(self):
        with patch.object(bridge,'_run_checked',return_value=b'0'*40):
            self.assertEqual(bridge.run('integrate')['status'],'INCOMPLETE')

    def test_git_override_environment_rejected(self):
        with patch.dict(os.environ,{'GIT_DIR':'/bad'}), patch.object(bridge,'_run_checked',return_value=(bridge.REV+'\n').encode()):
            self.assertEqual(bridge.run('integrate')['status'],'INCOMPLETE')

    def test_cycle_success_with_forged_local_dimension(self):
        v=dict(GOOD['cycle-locality']); v['local_span_dimension']=2
        self.assertEqual(self.patched_run('cycle-locality',lambda cmd,**kw:json.dumps(v).encode())['status'],'INCOMPLETE')

    def test_source_with_mismatched_git_blob(self):
        def fake(cmd,**kw):
            if 'show' in cmd: return b'correct git blob'
            return json.dumps({'path':bridge.SOURCE_PATH,'revision':bridge.REV,
                'repository':str(self.repo),'sha256':'0'*64,'source':'forged'}).encode()
        self.assertEqual(self.patched_run('source',fake)['status'],'INCOMPLETE')

    def test_unregistered_never_spawns(self):
        with patch.object(bridge,'_run_checked') as p:
            self.assertEqual(bridge.run('arbitrary-shell')['status'],'UNSUPPORTED')
            p.assert_not_called()

if __name__=='__main__': unittest.main()
