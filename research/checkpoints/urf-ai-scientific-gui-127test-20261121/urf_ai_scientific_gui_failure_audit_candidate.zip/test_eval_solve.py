import unittest
from exact_question import calculate, Unsupported

class EvaluationAndSolverTests(unittest.TestCase):
    def test_evaluate(self): self.assertEqual(calculate('Evaluate x^2 + 3*x at x = 5')['answer'],'40')
    def test_evaluate_fraction(self): self.assertEqual(calculate('Evaluate x^2 at x = 1/2')['answer'],'1/4')
    def test_evaluate_zero(self): self.assertEqual(calculate('Compute 3*x-2 at x = 0')['answer'],'-2')
    def test_evaluate_negative(self): self.assertEqual(calculate('What is x^2 when x = -3?')['answer'],'9')
    def test_linear(self): self.assertEqual(calculate('Solve 2*x+4=0')['roots'],['-2'])
    def test_quadratic(self): self.assertEqual(calculate('Solve x^2-4=0')['roots'],['-2','2'])
    def test_repeated(self): self.assertEqual(calculate('Solve (x-3)^2=0')['roots'],['3'])
    def test_rational_roots(self): self.assertEqual(calculate('Solve 4*x^2-1=0')['roots'],['-1/2','1/2'])
    def test_no_solution(self): self.assertEqual(calculate('Solve 2*x+1=2*x+2')['roots'],[])
    def test_all_rationals(self): self.assertEqual(calculate('Solve x=x')['solution_set'],'ALL_RATIONALS')
    def test_no_real_roots(self): self.assertEqual(calculate('Solve x^2+1=0')['detail'],'NO_REAL_ROOTS')
    def test_irrational_exact_radicals(self):
        r=calculate('Solve x^2-2=0')
        self.assertEqual(r['status'],'PROVED')
        self.assertEqual(r['detail'],'EXACT_QUADRATIC_RADICAL_ROOTS')
        self.assertEqual(r['roots'],['(-(0)-sqrt(8))/(2*(1))','(-(0)+sqrt(8))/(2*(1))'])
        self.assertEqual(r['representation'],'EXACT_SYMBOLIC_NOT_APPROXIMATE')
    def test_nonsymmetric_radicals(self):
        r=calculate('Solve 2*x^2+3*x-1=0')
        self.assertEqual(r['discriminant'],'17')
        self.assertEqual(r['roots'],['(-(3)-sqrt(17))/(2*(2))','(-(3)+sqrt(17))/(2*(2))'])
    def test_negative_quadratic_leading_coefficient(self):
        r=calculate('Solve -x^2+2=0')
        self.assertEqual(r['discriminant'],'8')
        self.assertIn('2*(-1)',r['roots'][0])
    def test_cubic_rejected(self):
        with self.assertRaisesRegex(Unsupported,'SOLVER_DEGREE'): calculate('Solve x^3-1=0')
    def test_injection_rejected(self):
        with self.assertRaises(Unsupported): calculate('Evaluate __import__("os") at x = 5')
    def test_fractional_zero_denominator_rejected(self):
        with self.assertRaises(Unsupported): calculate('Evaluate x at x = 1/0')
    def test_existing_identity(self): self.assertEqual(calculate('Is x^2-4=(x-2)*(x+2)?')['status'],'PROVED')
if __name__=='__main__':unittest.main()
