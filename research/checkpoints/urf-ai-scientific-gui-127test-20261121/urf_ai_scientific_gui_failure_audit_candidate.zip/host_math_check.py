"""Independent fixed-fixture host polynomial validation; no imports from worker engine."""
from __future__ import annotations
import hashlib
import json
from fractions import Fraction

BASELINE_HASH = '13a507c28d29cce85240c71dc347be5260c23154a24e61449acd13ea3b03fa6c'
REFERENCE = (Fraction(1), Fraction(2))
POINTS = (0, 1)
EXPECTED_VALUES = (Fraction(1), Fraction(3))

def strict_load(raw):
    def unique(pairs):
        obj = {}
        for k, v in pairs:
            if k in obj:
                raise ValueError('DUPLICATE_JSON_KEY')
            obj[k] = v
        return obj
    return json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('NONFINITE')))

def canonical_fraction(s):
    if type(s) is not str or len(s)>80:
        raise ValueError('INVALID_COEFFICIENT')
    f=Fraction(s)
    if str(f)!=s:
        raise ValueError('NONCANONICAL_COEFFICIENT')
    if f.numerator.bit_length()>256 or f.denominator.bit_length()>256:
        raise ValueError('OVERSIZED_COEFFICIENT')
    return f

def eval_poly(coeffs, x):
    total=Fraction(0)
    for c in reversed(coeffs):
        total=total*x+c
    return total

def check_worker_witness(baseline: bytes, receipt: dict):
    """Fail closed on fabricated success/edits/evaluations, independent of worker modules."""
    if type(baseline) is not bytes or len(baseline)>4096 or hashlib.sha256(baseline).hexdigest()!=BASELINE_HASH:
        raise ValueError('BASELINE_PIN')
    request=strict_load(baseline)
    if type(request) is not dict or set(request)!={'left','right'}:
        raise ValueError('REQUEST_SCHEMA')
    left,right=request['left'],request['right']
    if type(left) is not list or type(right) is not list or len(left)!=2 or len(right)!=2:
        raise ValueError('DEGREE_SCHEMA')
    left=tuple(canonical_fraction(s) for s in left)
    right=tuple(canonical_fraction(s) for s in right)
    if left != REFERENCE or any(eval_poly(REFERENCE,x)!=v for x,v in zip(POINTS,EXPECTED_VALUES)):
        raise ValueError('REFERENCE_NOT_AUTHORIZED')
    diffs=[i for i in range(2) if left[i]!=right[i]]
    if len(diffs)!=1:
        raise ValueError('NOT_SINGLE_REPAIR')
    if type(receipt) is not dict or 'corrected_coefficients' not in receipt:
        raise ValueError('MISSING_WITNESS')
    corrected=receipt['corrected_coefficients']
    if type(corrected) is not list or len(corrected)!=len(right):
        raise ValueError('WITNESS_SCHEMA')
    corrected=tuple(canonical_fraction(s) for s in corrected)
    if any(corrected[i] != (REFERENCE[i] if i==diffs[0] else right[i]) for i in range(2)):
        raise ValueError('UNAUTHORIZED_EDIT')
    if any(eval_poly(corrected,x)!=v for x,v in zip(POINTS,EXPECTED_VALUES)):
        raise ValueError('WITNESS_MATH_FAILURE')
    return True
