"""Deterministic one-coefficient repair relative to an explicitly trusted reference side.

Research-only. This computes a repair *relative to a chosen reference*; it cannot
establish that the reference polynomial is itself correct. No code execution,
filesystem writes, repository mutation, or authentication occurs here.
"""
from __future__ import annotations
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
from typing import Literal
from declarative_backtracking import Edit, Outcome, run_data_only
from scientific_adapter import parse_trial, trim, MAX_DEGREE

@dataclass(frozen=True)
class Discovery:
    status: str
    baseline_sha256: str
    reference_side: str
    proposed_edit: Edit | None
    attempted: int
    outcome: Outcome | None
    mismatch_count: int


def _s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'


def discover_one_edit(baseline: bytes, *, reference_side: Literal['left', 'right'],
                      expected_baseline_sha256: str | None = None) -> Discovery:
    """Find the unique single-coordinate repair when it exists and target is long enough.

    The reference is explicitly a hypothesis. Only the opposite side is edited.
    If >1 coefficient differs, this does not try a cumulative multi-edit repair.
    """
    if type(baseline) is not bytes:
        raise ValueError('INVALID_BASELINE')
    if type(reference_side) is not str or reference_side not in ('left', 'right'):
        raise ValueError('INVALID_REFERENCE_SIDE')
    if expected_baseline_sha256 is not None and type(expected_baseline_sha256) is not str:
        raise ValueError('INVALID_EXPECTED_HASH')
    # Validates lengths, sizes, number formats, schema before any further action.
    left, right = parse_trial(baseline)
    digest = sha256(baseline).hexdigest()
    def result(status: str, count: int, edit: Edit | None = None,
               outcome: Outcome | None = None, attempted: int = 0) -> Discovery:
        return Discovery(status, digest, reference_side, edit, attempted, outcome, count)
    if expected_baseline_sha256 is not None and digest != expected_baseline_sha256:
        return result('BLOCKED_BASELINE_MISMATCH', 0)
    reference, target = (left, right) if reference_side == 'left' else (right, left)
    ref = trim(reference)
    tgt = trim(target)
    n = max(len(ref), len(tgt))
    mismatches = [i for i in range(n) if (ref[i] if i < len(ref) else 0) !=
                  (tgt[i] if i < len(tgt) else 0)]
    if not mismatches:
        return result('BASELINE_ALREADY_EQUAL', 0)
    if len(mismatches) != 1:
        return result('OPEN_MULTIPLE_MISMATCHES', len(mismatches))
    i = mismatches[0]
    # No schema changes, padding, or extension of the target polynomial.
    if i >= len(target):
        return result('BLOCKED_TARGET_INDEX_ABSENT', 1)
    desired = ref[i] if i < len(ref) else Fraction(0)
    edit = Edit('right' if reference_side == 'left' else 'left', i, _s(desired))
    outcome = run_data_only(baseline, [edit], max_attempts=1,
                            expected_baseline_sha256=digest)
    if outcome.status != 'COMPUTATION_PASS_NOT_PROMOTED':
        return result('NOT_VERIFIED', 1, edit, outcome, 1)
    return result('COMPUTATION_PASS_NOT_PROMOTED', 1, edit, outcome, 1)
