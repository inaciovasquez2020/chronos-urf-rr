import http.client
import json
import threading
import unittest
from http.server import HTTPServer
from research_console import make_handler, SUPPORTED_QUESTION

class ResearchConsoleTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        def runner():
            self.calls.append('RUN')
            return 'DOCKER_FIXTURE_COMPUTATION_PASS_NOT_PROMOTED'
        self.server = HTTPServer(('127.0.0.1', 0), make_handler('fixed-test-token', 0, runner))
        self.port = self.server.server_address[1]
        self.server.RequestHandlerClass = make_handler('fixed-test-token', self.port, runner)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
    def send(self, method='POST', path='/fixed-test-token/run', data=None, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=3)
        h = {'Host':'127.0.0.1:'+str(self.port)}
        if method == 'POST':
            h.update({'Content-Type':'application/json','X-URF-Confirm':'RUN_REGISTERED_FIXTURE'})
        if headers: h.update(headers)
        body = data if data is not None else json.dumps({'question':SUPPORTED_QUESTION})
        if method != 'POST': body = None
        conn.request(method,path,body=body,headers=h)
        res=conn.getresponse()
        output = res.read()
        status = res.status
        conn.close()
        return status, output
    def test_inline_script_uses_escaped_newlines(self):
        status, body = self.send('GET','/fixed-test-token/')
        self.assertEqual(status, 200)
        self.assertIn(b"j.status+'\\nDETAIL: '+j.detail+'\\nRESULT:", body)
        self.assertNotIn(b"j.status+'\nDETAIL", body)
    def test_valid_runs_once(self):
        status, body=self.send()
        self.assertEqual(status,200)
        self.assertEqual(json.loads(body)['status'],'COMPUTATION_PASS')
        self.assertEqual(self.calls,['RUN'])
    def test_get_page(self):
        status, body=self.send('GET','/fixed-test-token/')
        self.assertEqual(status,200)
        self.assertIn(b'URF-AI Research Console',body)
    def test_wrong_path(self):
        self.assertEqual(self.send(path='/run')[0],403)
        self.assertEqual(self.calls,[])
    def test_bad_origin(self):
        self.assertEqual(self.send(headers={'Origin':'http://evil.invalid'})[0],403)
        self.assertEqual(self.calls,[])
    def test_direct_address_bar_navigation_allowed(self):
        status, body = self.send('GET','/fixed-test-token/',headers={'Sec-Fetch-Site':'none'})
        self.assertEqual(status, 200)
        self.assertIn(b'URF-AI Research Console',body)
    def test_direct_navigation_does_not_authorize_execution(self):
        status, body = self.send(headers={'Sec-Fetch-Site':'none'})
        self.assertEqual(status,403)
        self.assertEqual(self.calls,[])
    def test_cross_site_navigation_denied(self):
        self.assertEqual(self.send('GET','/fixed-test-token/',headers={'Sec-Fetch-Site':'cross-site'})[0],403)
    def test_bad_origin_navigation_denied(self):
        self.assertEqual(self.send('GET','/fixed-test-token/',headers={'Origin':'https://example.org','Sec-Fetch-Site':'none'})[0],403)
    def test_cross_site(self):
        self.assertEqual(self.send(headers={'Sec-Fetch-Site':'cross-site'})[0],403)
        self.assertEqual(self.calls,[])
    def test_bad_host(self):
        self.assertEqual(self.send(headers={'Host':'localhost:'+str(self.port)})[0],403)
        self.assertEqual(self.calls,[])
    def test_missing_confirmation(self):
        self.assertEqual(self.send(headers={'X-URF-Confirm':'NO'})[0],403)
        self.assertEqual(self.calls,[])
    def test_unknown_question_rejected(self):
        status,body=self.send(data=json.dumps({'question':'Prove the Poincare conjecture'}))
        self.assertEqual(status,422)
        self.assertEqual(json.loads(body)['status'],'UNSUPPORTED')
        self.assertEqual(self.calls,[])
    def test_duplicate_json(self):
        self.assertEqual(self.send(data='{"question":"a","question":"b"}')[0],400)
        self.assertEqual(self.calls,[])
    def test_oversize_input(self):
        self.assertEqual(self.send(data='x'*2200)[0],413)
        self.assertEqual(self.calls,[])
    def test_wrong_type(self):
        self.assertEqual(self.send(data='{"question":42}')[0],400)
        self.assertEqual(self.calls,[])
    def test_failure_closed(self):
        self.server.RequestHandlerClass=make_handler('fixed-test-token',self.port,lambda:'INCOMPLETE_TIMEOUT')
        status,body=self.send()
        self.assertEqual(json.loads(body)['status'],'INCOMPLETE')
    def test_exception_closed(self):
        def explode(): raise RuntimeError('broken')
        self.server.RequestHandlerClass=make_handler('fixed-test-token',self.port,explode)
        self.assertEqual(json.loads(self.send()[1])['status'],'INCOMPLETE')

if __name__=='__main__': unittest.main()
