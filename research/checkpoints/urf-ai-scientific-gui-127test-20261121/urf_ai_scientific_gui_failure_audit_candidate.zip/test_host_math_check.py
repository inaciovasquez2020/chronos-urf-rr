import unittest
import json
from pathlib import Path
from host_math_check import check_worker_witness, strict_load, BASELINE_HASH

BASE = Path(__file__).with_name('baseline.json').read_bytes()
RECEIPT = {'corrected_coefficients':['1','2']}

class HostMathTests(unittest.TestCase):
    def test_valid(self):
        self.assertTrue(check_worker_witness(BASE,RECEIPT))
    def test_wrong_answer(self):
        with self.assertRaisesRegex(ValueError, 'UNAUTHORIZED_EDIT'):
            check_worker_witness(BASE,{'corrected_coefficients':['1','3']})
    def test_forged_success_without_witness(self):
        with self.assertRaisesRegex(ValueError,'MISSING_WITNESS'):
            check_worker_witness(BASE,{'status':'HOST_BOUND_FIXTURE_PASS_NOT_PROMOTED'})
    def test_wrong_size(self):
        with self.assertRaisesRegex(ValueError,'WITNESS_SCHEMA'):
            check_worker_witness(BASE,{'corrected_coefficients':['1']})
    def test_wrong_type(self):
        with self.assertRaisesRegex(ValueError,'WITNESS_SCHEMA'):
            check_worker_witness(BASE,{'corrected_coefficients':'1,2'})
    def test_bad_baseline(self):
        with self.assertRaisesRegex(ValueError,'BASELINE_PIN'):
            check_worker_witness(BASE+b' ', RECEIPT)
    def test_noncanonical(self):
        with self.assertRaisesRegex(ValueError,'NONCANONICAL_COEFFICIENT'):
            check_worker_witness(BASE,{'corrected_coefficients':['01','2']})
    def test_duplicate_json(self):
        with self.assertRaisesRegex(ValueError,'DUPLICATE_JSON_KEY'):
            strict_load(b'{"left":[],"left":[]}')
    def test_unchanged_non_error_coefficient(self):
        with self.assertRaisesRegex(ValueError,'UNAUTHORIZED_EDIT'):
            check_worker_witness(BASE,{'corrected_coefficients':['0','2']})
    def test_reject_float(self):
        with self.assertRaisesRegex(ValueError,'INVALID_COEFFICIENT'):
            check_worker_witness(BASE,{'corrected_coefficients':[1.0,'2']})

if __name__ == '__main__': unittest.main()
