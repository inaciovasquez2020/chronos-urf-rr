import unittest
from exact_question import calculate,Unsupported
class ExactQuestionTests(unittest.TestCase):
    def test_arithmetic(self): self.assertEqual(calculate('2+2')['answer'],'4')
    def test_fraction(self): self.assertEqual(calculate('1/3+1/6')['answer'],'1/2')
    def test_identity(self): self.assertEqual(calculate('Is x² - 4 = (x - 2)*(x + 2)?')['status'],'PROVED')
    def test_false_identity(self): self.assertEqual(calculate('x^2+1=x^2+2')['status'],'REFUTED')
    def test_fraction_identity(self): self.assertEqual(calculate('Verify 1/3 + 1/6 = 1/2')['status'],'PROVED')
    def test_no_eval(self):
        with self.assertRaises(Unsupported): calculate('__import__("os").system("echo bad")')
    def test_no_implicit_mult(self):
        with self.assertRaises(Unsupported): calculate('2x = x+x')
    def test_exponent_limit(self):
        with self.assertRaises(Unsupported): calculate('x^100=x^100')
    def test_division_reject(self):
        with self.assertRaises(Unsupported): calculate('1/x=2')
    def test_binomial_power(self): self.assertEqual(calculate('(x+1)^3=x^3+3*x^2+3*x+1')['status'],'PROVED')
    def test_difference(self): self.assertEqual(calculate('x=x+1')['difference'],{'0':'-1'})
    def test_constant_large(self):
        with self.assertRaises(Unsupported): calculate(str(2**300)+'=1')
if __name__=='__main__': unittest.main()
