"""Bounded, data-only exact polynomial correction.

No candidate Python code, no subprocess, no import of the snapshot, no filesystem
writes, no promotion. Receipt authenticates neither a caller nor an execution.
"""
from __future__ import annotations
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from fractions import Fraction
from typing import Sequence
from scientific_adapter import parse_trial, rational, trusted_verify, MAX_INPUT

MAX_ATTEMPTS = 8

@dataclass(frozen=True)
class Edit:
    side: str
    index: int
    value: str

@dataclass(frozen=True)
class Record:
    ordinal: int
    status: str
    candidate_sha256: str | None
    reason: str

@dataclass(frozen=True)
class Outcome:
    status: str
    baseline_sha256: str
    accepted_candidate: bytes | None
    records: tuple[Record, ...]


def canonical(left: tuple[Fraction, ...], right: tuple[Fraction, ...]) -> bytes:
    def f(v: Fraction) -> str:
        return str(v.numerator) if v.denominator == 1 else f'{v.numerator}/{v.denominator}'
    return json.dumps({'left': [f(x) for x in left], 'right': [f(x) for x in right]},
                      sort_keys=True, separators=(',', ':')).encode('utf-8')


def apply_edit(baseline: bytes, edit: Edit) -> bytes:
    if type(edit) is not Edit or edit.side not in ('left', 'right'):
        raise ValueError('INVALID_EDIT')
    if type(edit.index) is not int or edit.index < 0:
        raise ValueError('INVALID_INDEX')
    v = rational(edit.value)
    left, right = parse_trial(baseline)
    target = list(left if edit.side == 'left' else right)
    if edit.index >= len(target):
        raise ValueError('INDEX_OUT_OF_BOUNDS')
    target[edit.index] = v
    proposal = canonical(tuple(target), right) if edit.side == 'left' else canonical(left, tuple(target))
    if len(proposal) > MAX_INPUT:
        raise ValueError('INPUT_LIMIT')
    return proposal


def run_data_only(baseline: bytes, edits: Sequence[Edit], *, max_attempts: int = 2,
                  expected_baseline_sha256: str | None = None) -> Outcome:
    if type(baseline) is not bytes or len(baseline) > MAX_INPUT:
        raise ValueError('INVALID_BASELINE')
    parse_trial(baseline)
    if type(max_attempts) is not int or not 1 <= max_attempts <= MAX_ATTEMPTS:
        raise ValueError('INVALID_ATTEMPT_LIMIT')
    if type(edits) not in (tuple, list) or len(edits) > MAX_ATTEMPTS:
        raise ValueError('INVALID_EDIT_LIST')
    digest = sha256(baseline).hexdigest()
    if expected_baseline_sha256 is not None and (type(expected_baseline_sha256) is not str or
                                                 expected_baseline_sha256 != digest):
        return Outcome('BLOCKED_BASELINE_MISMATCH', digest, None, ())
    records = []
    for i, edit in enumerate(edits[:max_attempts], 1):
        try:
            trial = apply_edit(baseline, edit)
            if parse_trial(trial) == parse_trial(baseline):
                records.append(Record(i, 'REJECTED', None, 'NO_OP'))
                continue
            candidate_sha = sha256(trial).hexdigest()
            verdict = trusted_verify(trial)
            if type(verdict.compile_pass) is not bool or type(verdict.axiom_pass) is not bool:
                raise ValueError('INVALID_VERDICT')
            if verdict.compile_pass and verdict.axiom_pass:
                records.append(Record(i, 'ACCEPTED_ISOLATED', candidate_sha,
                                      'EXACT_POLYNOMIAL_IDENTITY'))
                return Outcome('COMPUTATION_PASS_NOT_PROMOTED', digest, trial, tuple(records))
            records.append(Record(i, 'REJECTED', candidate_sha, verdict.detail))
        except (TypeError, ValueError, OverflowError, IndexError) as error:
            records.append(Record(i, 'REJECTED', None, type(error).__name__))
    return Outcome('NOT_VERIFIED', digest, None, tuple(records))
