"""Bounded exact polynomial checker. No eval, sympy, or worker-generated certificates."""
from __future__ import annotations
import ast
from math import isqrt
import re
from fractions import Fraction

MAX_LENGTH = 220
MAX_DEGREE = 12
MAX_BITS = 256
MAX_NODES = 70

class Unsupported(ValueError):
    pass

def clean(p):
    return {k:v for k,v in p.items() if v}

def checked(p):
    if len(p)>MAX_NODES or any(k<0 or k>MAX_DEGREE or v.numerator.bit_length()>MAX_BITS or v.denominator.bit_length()>MAX_BITS for k,v in p.items()):
        raise Unsupported('RESOURCE_BOUND')
    return clean(p)

def add(a,b):
    out=dict(a)
    for k,v in b.items(): out[k]=out.get(k, Fraction(0))+v
    return checked(out)

def neg(a): return {k:-v for k,v in a.items()}

def mul(a,b):
    out={}
    for i,x in a.items():
        for j,y in b.items():
            if i+j>MAX_DEGREE: raise Unsupported('DEGREE_LIMIT')
            out[i+j]=out.get(i+j,Fraction(0))+x*y
    return checked(out)

def expr(node, counter):
    counter[0]+=1
    if counter[0]>MAX_NODES: raise Unsupported('NODE_LIMIT')
    if isinstance(node, ast.Constant) and type(node.value) is int:
        if node.value.bit_length()>MAX_BITS: raise Unsupported('INTEGER_LIMIT')
        return {0:Fraction(node.value)} if node.value else {}
    if isinstance(node, ast.Name) and node.id=='x': return {1:Fraction(1)}
    if isinstance(node,ast.UnaryOp) and type(node.op) in (ast.UAdd,ast.USub):
        a=expr(node.operand,counter)
        return a if type(node.op) is ast.UAdd else neg(a)
    if isinstance(node,ast.BinOp):
        op=type(node.op)
        if op is ast.Pow:
            if not isinstance(node.right,ast.Constant) or type(node.right.value) is not int or not 0<=node.right.value<=MAX_DEGREE:
                raise Unsupported('EXPONENT_LIMIT')
            a=expr(node.left,counter); out={0:Fraction(1)}
            for _ in range(node.right.value): out=mul(out,a)
            return out
        a=expr(node.left,counter); b=expr(node.right,counter)
        if op is ast.Add:return add(a,b)
        if op is ast.Sub:return add(a,neg(b))
        if op is ast.Mult:return mul(a,b)
        if op is ast.Div:
            if set(b)-{0} or not b.get(0): raise Unsupported('NONCONSTANT_DIVISION')
            return checked({k:v/b[0] for k,v in a.items()})
    raise Unsupported('UNSUPPORTED_SYNTAX')

def polynomial(s):
    if len(s)>MAX_LENGTH or not re.fullmatch(r'[0-9xX+*/^().\s-]+',s):
        raise Unsupported('CHARACTER_OR_LENGTH_LIMIT')
    s=s.replace('^','**').replace('X','x')
    try: tree=ast.parse(s,mode='eval')
    except (SyntaxError, ValueError, RecursionError):raise Unsupported('PARSE_ERROR')
    try:return checked(expr(tree.body,[0]))
    except (RecursionError,OverflowError,ZeroDivisionError):raise Unsupported('RESOURCE_OR_ZERO_DIVISION')

def fraction_string(v):return str(v.numerator) if v.denominator==1 else str(v.numerator)+'/'+str(v.denominator)

def exact_eval(p, x):
    """Evaluate a polynomial at a rational argument; no floating point."""
    result = Fraction(0)
    for i in range(max(p, default=-1), -1, -1):
        result = result*x + p.get(i, Fraction(0))
    return result

def identity_counterexample(left, right):
    """For a nonzero degree <= 12 difference, 13 distinct x values suffice."""
    diff = add(left, neg(right))
    if not diff:
        raise Unsupported('NO_DIFFERENCE')
    for x in (0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6):
        point = Fraction(x)
        a, b = exact_eval(left, point), exact_eval(right, point)
        if a != b:
            if max(a.numerator.bit_length(), a.denominator.bit_length(),
                   b.numerator.bit_length(), b.denominator.bit_length()) > 512:
                raise Unsupported('WITNESS_SIZE_LIMIT')
            return {'x': str(x), 'left': fraction_string(a), 'right': fraction_string(b)}
    raise Unsupported('COUNTEREXAMPLE_NOT_FOUND')

def normalized(p):return {str(k):fraction_string(v) for k,v in sorted(p.items())}

def solve_equation(equation):
    """Solve degree <=2 equations over Q, with explicit incompleteness for irrational roots."""
    if equation.count('=') != 1:
        raise Unsupported('EQUATION_REQUIRED')
    left, right = (part.strip() for part in equation.split('=', 1))
    if not left or not right:
        raise Unsupported('EMPTY_SIDE')
    d = add(polynomial(left), neg(polynomial(right)))
    degree = max(d, default=-1)
    if degree == -1:
        return {'status':'PROVED','detail':'ALL_RATIONAL_VALUES_SATISFY', 'solution_set':'ALL_RATIONALS'}
    if degree == 0:
        return {'status':'PROVED','detail':'NO_RATIONAL_OR_REAL_SOLUTIONS', 'roots':[]}
    a = d[degree]
    if degree == 1:
        root = -d.get(0, Fraction(0)) / a
        if root.numerator.bit_length()>MAX_BITS or root.denominator.bit_length()>MAX_BITS:
            raise Unsupported('ROOT_SIZE_LIMIT')
        return {'status':'PROVED','detail':'EXACT_LINEAR_ROOT', 'roots':[fraction_string(root)]}
    if degree > 2:
        raise Unsupported('SOLVER_DEGREE_LIMIT')
    b, c = d.get(1, Fraction(0)), d.get(0, Fraction(0))
    disc = b*b - 4*a*c
    if disc < 0:
        return {'status':'PROVED', 'detail':'NO_REAL_ROOTS', 'roots':[]}
    numerator, denominator = isqrt(disc.numerator), isqrt(disc.denominator)
    if numerator*numerator != disc.numerator or denominator*denominator != disc.denominator:
        # Exact radical representation, not a floating-point approximation.
        # Independent rational certificate: (2*a*x+b)^2=disc,
        # which expands to 4*a*(a*x*x+b*x+c)=0.
        if 4*a*c != b*b-disc:
            raise Unsupported('DISCRIMINANT_CERTIFICATE_FAILED')
        aa, bb, dd = fraction_string(a), fraction_string(b), fraction_string(disc)
        roots = [f'(-({bb})-sqrt({dd}))/(2*({aa}))',
                 f'(-({bb})+sqrt({dd}))/(2*({aa}))']
        return {'status':'PROVED','detail':'EXACT_QUADRATIC_RADICAL_ROOTS',
                'roots':roots,'discriminant':dd,'representation':'EXACT_SYMBOLIC_NOT_APPROXIMATE'}
    sq = Fraction(numerator, denominator)
    roots = sorted(set(((-b-sq)/(2*a), (-b+sq)/(2*a))))
    if any(v.numerator.bit_length()>MAX_BITS or v.denominator.bit_length()>MAX_BITS for v in roots):
        raise Unsupported('ROOT_SIZE_LIMIT')
    # Verify each root independently by Horner evaluation against original coefficients.
    for root in roots:
        if a*root*root+b*root+c:
            raise Unsupported('ROOT_VERIFICATION_FAILED')
    return {'status':'PROVED','detail':'EXACT_QUADRATIC_RATIONAL_ROOTS', 'roots':[fraction_string(v) for v in roots]}

def evaluate_at(question):
    match = re.fullmatch(r'(?:evaluate|compute|what\s+is)\s+(.+?)\s+(?:at\s+)?(?:when\s+)?x\s*=\s*([+-]?[0-9]+(?:/[0-9]+)?)',question,flags=re.I)
    if not match:
        raise Unsupported('EVALUATION_SYNTAX')
    p = polynomial(match.group(1))
    raw = match.group(2)
    if len(raw) > 90:
        raise Unsupported('VALUE_LIMIT')
    try:
        x = Fraction(raw)
    except (ValueError,ZeroDivisionError):
        raise Unsupported('INVALID_VALUE')
    if x.numerator.bit_length()>MAX_BITS or x.denominator.bit_length()>MAX_BITS:
        raise Unsupported('VALUE_LIMIT')
    out = Fraction(0)
    for exponent in range(max(p, default=-1),-1,-1):
        out=out*x+p.get(exponent,Fraction(0))
        if out.numerator.bit_length()>MAX_BITS or out.denominator.bit_length()>MAX_BITS:
            raise Unsupported('RESULT_LIMIT')
    return {'status':'COMPUTATION_PASS','detail':'EXACT_POLYNOMIAL_SUBSTITUTION', 'at':fraction_string(x), 'answer':fraction_string(out)}

def calculate(question):
    if type(question) is not str or len(question)>MAX_LENGTH: raise Unsupported('QUESTION_LIMIT')
    q=question.strip().replace('²','^2').replace('³','^3').replace('−','-').replace('×','*').replace('÷','/')
    q=re.sub(r'^(?:is|verify|check)\s+', '',q,flags=re.I)
    q=q.rstrip('?.! ')
    if re.match(r'^solve\s+',q,flags=re.I):
        return solve_equation(re.sub(r'^solve\s+', '',q, flags=re.I))
    if re.match(r'^(?:evaluate|compute|what\s+is)\s+',q,flags=re.I) and re.search(r'\bx\s*=\s*[+-]?[0-9]',q):
        return evaluate_at(q)
    # Allow one equality or equality free constant arithmetic. No implicit multiplication.
    if q.count('=')>1: raise Unsupported('MULTIPLE_EQUALITIES')
    if '=' in q:
        left,right=map(str.strip,q.split('=',1))
        if not left or not right: raise Unsupported('EMPTY_SIDE')
        a=polynomial(left); b=polynomial(right)
        d=add(a,neg(b))
        result = {'status':'PROVED' if not d else 'REFUTED', 'detail':'EXACT_POLYNOMIAL_IDENTITY' if not d else 'POLYNOMIALS_DIFFER', 'left':normalized(a),'right':normalized(b),'difference':normalized(d)}
        if d:
            result['counterexample'] = identity_counterexample(a, b)
        return result
    p=polynomial(q)
    if set(p)-{0}: raise Unsupported('VARIABLE_EXPRESSION_NEEDS_EQUALITY')
    return {'status':'COMPUTATION_PASS','detail':'EXACT_RATIONAL_ARITHMETIC','answer':fraction_string(p.get(0,Fraction(0)))}
