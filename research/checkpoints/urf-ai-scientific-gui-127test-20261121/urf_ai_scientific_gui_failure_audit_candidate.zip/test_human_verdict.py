"""Presentation-only verdict assertions; no change to engine contract."""
import json, re, subprocess, shutil, unittest
from research_console import PAGE
from exact_question import calculate

class HumanVerdictTests(unittest.TestCase):
    def test_engine_status_unchanged(self):
        for q,detail in [ ('Solve x^2+1=0','NO_REAL_ROOTS'),('Solve 2=3','NO_RATIONAL_OR_REAL_SOLUTIONS'),('Solve x^2-4=0','EXACT_QUADRATIC_RATIONAL_ROOTS'),('Solve x=x','ALL_RATIONAL_VALUES_SATISFY') ]:
            obj=calculate(q)
            self.assertEqual(obj['status'],'PROVED')
            self.assertEqual(obj['detail'],detail)
    def test_browser_human_verdict_js(self):
        if not shutil.which('node'):
            self.skipTest('Node unavailable; browser runtime check INCOMPLETE')
        script=re.search(r'<script nonce="SCRIPT_NONCE">(.*?)</script>',PAGE,re.S).group(1)
        fn=re.search(r'function humanFinding\(j\)\{.*?\n\}',script,re.S).group(0)
        inputs=[(calculate('Solve x^2+1=0'),'NO REAL SOLUTIONS'),
                (calculate('Solve 2=3'),'NO REAL SOLUTIONS'),
                (calculate('Solve x=x'),'ALL RATIONAL VALUES SATISFY THE EQUATION'),
                (calculate('Solve x^2-4=0'),'EXACT QUADRATIC SOLUTIONS'),
                (calculate('Is x^2-4=0?'),'IDENTITY FALSE'),
                (calculate('Is x^2-4=(x-2)*(x+2)?'),'IDENTITY HOLDS FOR ALL x')]
        test=fn+'\nconst pairs='+json.dumps(inputs)+'; for(const [input,expected] of pairs){if(humanFinding(input)!==expected)process.exit(2)}'
        r=subprocess.run(['node','-e',test],capture_output=True,text=True,timeout=5)
        self.assertEqual(r.returncode,0,r.stderr)
    def test_full_browser_script_parses(self):
        if not shutil.which('node'):
            self.skipTest('Node unavailable; browser syntax check INCOMPLETE')
        script=re.search(r'<script nonce="SCRIPT_NONCE">(.*?)</script>',PAGE,re.S).group(1)
        # Node parses the entire delivered script, including the output template.
        import tempfile, os
        fd,path=tempfile.mkstemp(suffix='.js')
        try:
            with os.fdopen(fd,'w') as f: f.write(script)
            r=subprocess.run(['node','--check',path],capture_output=True,text=True,timeout=5)
            self.assertEqual(r.returncode,0,r.stderr)
        finally:
            os.unlink(path)
    def test_not_overclaiming_unknown_status(self):
        self.assertIn("return 'NO HUMAN VERDICT AVAILABLE'",PAGE)

if __name__=='__main__':unittest.main()
