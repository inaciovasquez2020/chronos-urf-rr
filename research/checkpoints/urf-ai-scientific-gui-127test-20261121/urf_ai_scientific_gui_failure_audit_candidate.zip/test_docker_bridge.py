import unittest
from unittest.mock import patch
from docker_bridge import build_command,check_receipt,run,EXPECTED_BASELINE
import json
import os
import subprocess
import sys
import time
class BridgeTests(unittest.TestCase):
 def test_security_flags(self):
  c=build_command('/tmp/only-disposable-input','urf-ai-research-bridge-abc')
  for x in ('--read-only','--network=none','--cap-drop=ALL','--pull=never','--memory=128m','--pids-limit=32','--user=65534:65534'):
   self.assertIn(x,c)
  self.assertIn('type=bind,src=/tmp/only-disposable-input,dst=/input,readonly',c)
  self.assertNotIn('--privileged',c)
 def test_duplicate_receipt_rejected(self):
  with self.assertRaises(ValueError):check_receipt(b'{"status":"a","status":"b"}',{})
 def test_status_forgery_rejected(self):
  with self.assertRaises(ValueError):check_receipt(b'{"status":"PROVED"}',{'status':'CONDITIONAL'})
 def test_non_dict_receipt_rejected(self):
  with self.assertRaises(ValueError):check_receipt(b'[]',{})
 def test_oversize_rejected(self):
  with self.assertRaises(ValueError):check_receipt(b'x'*8193,{})
 def test_exact_receipt_allowed(self):
  a={'status':'FIXTURE','baseline_sha256':EXPECTED_BASELINE,'registered_evidence_sha256':'a'*64,'input_sha256':EXPECTED_BASELINE,'corrected_coefficients':['1','2']}
  self.assertTrue(check_receipt(json.dumps(a).encode(),a))
 def test_no_image_no_execution(self):
  from types import SimpleNamespace
  with patch('docker_bridge.subprocess.run',return_value=SimpleNamespace(returncode=1,stdout='',stderr='')) as p:
   self.assertEqual(run(),'BLOCKED_IMAGE_PIN')
   self.assertEqual(p.call_count,1)
 def test_host_output_flood_stopped_early(self):
  from docker_bridge import limited_run
  start=time.monotonic()
  code='import sys\nwhile True: sys.stdout.write("x"*4096);sys.stdout.flush()'
  with self.assertRaisesRegex(ValueError,'OUTPUT_LIMIT'):
   limited_run([sys.executable,'-B','-c',code],5)
  self.assertLess(time.monotonic()-start,4)
 def test_host_stderr_flood_stopped_early(self):
  from docker_bridge import limited_run
  code='import sys\nwhile True: sys.stderr.write("x"*4096);sys.stderr.flush()'
  with self.assertRaisesRegex(ValueError,'OUTPUT_LIMIT'):
   limited_run([sys.executable,'-B','-c',code],5)
 def test_host_timeout_fail_closed(self):
  from docker_bridge import limited_run
  with self.assertRaises(subprocess.TimeoutExpired):
   limited_run([sys.executable,'-B','-c','import time;time.sleep(3)'],.2)
 def test_bounded_success(self):
  from docker_bridge import limited_run
  rc,out,err=limited_run([sys.executable,'-B','-c','print("OK")'],3)
  self.assertEqual((rc,out,err),(0,b'OK\n',b''))
 def test_output_failure_stops_only_own_container(self):
  from types import SimpleNamespace
  from docker_bridge import run
  fake=SimpleNamespace(returncode=0,stdout='sha256:fa6269e572095db0e631e87e04950de3715d3825730d1ce716720cf98fabc53c',stderr='')
  with patch('docker_bridge.subprocess.run',return_value=fake),\
       patch('docker_bridge.limited_run',side_effect=ValueError('OUTPUT_LIMIT')),\
       patch('docker_bridge.stop_own_container',return_value=True) as stop:
   self.assertEqual(run(),'INCOMPLETE_OUTPUT_LIMIT')
   self.assertEqual(stop.call_count,1)
   self.assertTrue(stop.call_args.args[0].startswith('urf-ai-research-bridge-'))
if __name__=='__main__':unittest.main()
