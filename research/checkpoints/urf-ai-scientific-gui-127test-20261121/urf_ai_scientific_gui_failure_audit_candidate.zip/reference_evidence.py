"""Conditional reference validation by independently specified exact evaluations.

Evidence is an externally trusted *assumption*, NOT a cryptographic attestation.
The SHA256 pin protects against substitution only if the pin originates outside
untrusted candidate input. This module does not execute candidate code.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import json
import re
from deterministic_generator import discover_one_edit, Discovery
from scientific_adapter import parse_trial, evaluate, rational, trim, MAX_INPUT, MAX_DEGREE

@dataclass(frozen=True)
class EvidenceOutcome:
    status: str
    reference_validated: bool
    baseline_sha256: str
    evidence_sha256: str | None
    discovery: Discovery | None


def verify_with_pinned_evaluations(baseline: bytes, *, reference_side: str,
                                   evidence: bytes, trusted_evidence_sha256: str) -> EvidenceOutcome:
    """Run v3 only if the reference matches independently pinned d+1 evaluations.

    Evidence JSON exactly {'values': ['...']} denotes y_i=P(i), i=0,...,d.
    A degree <= d polynomial is uniquely determined by these d+1 values.
    Here d is max degree of either supplied baseline polynomial.
    """
    if type(baseline) is not bytes:
        raise ValueError('INVALID_BASELINE')
    left, right = parse_trial(baseline)
    basehash = sha256(baseline).hexdigest()
    if type(reference_side) is not str or reference_side not in ('left', 'right'):
        raise ValueError('INVALID_REFERENCE_SIDE')
    if (type(trusted_evidence_sha256) is not str or
        re.fullmatch(r'[0-9a-f]{64}', trusted_evidence_sha256) is None):
        raise ValueError('INVALID_TRUST_PIN')
    if type(evidence) is not bytes or len(evidence) > MAX_INPUT:
        raise ValueError('INVALID_EVIDENCE')
    evidence_hash = sha256(evidence).hexdigest()
    def blocked(reason):
        return EvidenceOutcome(reason, False, basehash, evidence_hash, None)
    if evidence_hash != trusted_evidence_sha256:
        return blocked('BLOCKED_EVIDENCE_HASH_MISMATCH')
    try:
        obj = json.loads(evidence.decode('utf-8', 'strict'))
        if type(obj) is not dict or set(obj) != {'values'}:
            return blocked('BLOCKED_EVIDENCE_SCHEMA')
        degree = max(len(left), len(right)) - 1
        if (type(obj['values']) is not list or
            len(obj['values']) != degree + 1 or degree > MAX_DEGREE):
            return blocked('BLOCKED_EVIDENCE_POINTS')
        values = tuple(rational(y) for y in obj['values'])
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return blocked('BLOCKED_EVIDENCE_INVALID')
    reference = left if reference_side == 'left' else right
    if any(evaluate(reference, i) != values[i] for i in range(degree + 1)):
        return blocked('BLOCKED_REFERENCE_CONTRADICTS_EVIDENCE')
    discovery = discover_one_edit(baseline, reference_side=reference_side,
                                   expected_baseline_sha256=basehash)
    if discovery.status != 'COMPUTATION_PASS_NOT_PROMOTED':
        return EvidenceOutcome(discovery.status, True, basehash, evidence_hash, discovery)
    # Re-check independent evaluations on the resulting two polynomials.
    if discovery.outcome is None or discovery.outcome.accepted_candidate is None:
        return blocked('NOT_VERIFIED')
    a, b = parse_trial(discovery.outcome.accepted_candidate)
    if any(evaluate(a,i) != values[i] or evaluate(b,i) != values[i]
           for i in range(degree + 1)):
        return blocked('BLOCKED_CANDIDATE_CONTRADICTS_EVIDENCE')
    return EvidenceOutcome('CONDITIONAL_COMPUTATION_PASS_NOT_PROMOTED', True,
                           basehash, evidence_hash, discovery)
