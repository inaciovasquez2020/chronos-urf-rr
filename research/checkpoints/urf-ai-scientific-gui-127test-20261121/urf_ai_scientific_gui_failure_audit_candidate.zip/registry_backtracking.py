"""Fail-closed reference validation against code-pinned research fixtures.

The API intentionally has NO evidence, expected hash, or reference_side args.
No filesystem writes, network, imports of candidate code, or mutable state.
NOT proof of provenance authenticity. NOT production promotion.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import json

from trusted_registry import lookup, fixture_digest
from reference_evidence import verify_with_pinned_evaluations
from scientific_adapter import parse_trial, rational, trim, evaluate

@dataclass(frozen=True)
class RegistryResult:
    status: str
    task_id: str
    registry_record_sha256: str | None
    baseline_sha256: str
    correction: object | None
    source_label: str | None


def verify_registered_task(baseline: bytes, *, task_id: str) -> RegistryResult:
    """Evaluate a designated task using only registry-controlled evidence.

    All task binding happens before candidate correction. Unknown tasks fail
    closed. A registry is part of the trusted distribution, not a user file.
    """
    if type(baseline) is not bytes:
        raise ValueError('INVALID_BASELINE')
    digest = sha256(baseline).hexdigest()
    def reject(status: str) -> RegistryResult:
        return RegistryResult(status, task_id, None, digest, None, None)
    try:
        fixture = lookup(task_id)
    except ValueError:
        return reject('BLOCKED_UNKNOWN_TASK')
    left, right = parse_trial(baseline)
    reference = left if fixture.reference_side == 'left' else right
    canonical = tuple(rational(x) for x in fixture.coefficients)
    # Bind the *actual reference coefficients* and exact degree to this task,
    # not merely user-supplied evaluations or an untrusted status boolean.
    if trim(reference) != canonical or len(reference) != len(canonical):
        return reject('BLOCKED_REFERENCE_NOT_REGISTERED')
    if max(len(left), len(right)) > len(canonical):
        return reject('BLOCKED_DEGREE_OUTSIDE_REGISTERED_TASK')
    values = tuple(rational(y) for y in fixture.values)
    if len(values) != len(canonical):
        return reject('BLOCKED_INVALID_REGISTRY_RECORD')
    if any(evaluate(canonical, i) != values[i] for i in range(len(values))):
        return reject('BLOCKED_INVALID_REGISTRY_RECORD')
    evidence = json.dumps({'values': list(fixture.values)},
                          sort_keys=True, separators=(',', ':')).encode('utf-8')
    result = verify_with_pinned_evaluations(
        baseline, reference_side=fixture.reference_side,
        evidence=evidence, trusted_evidence_sha256=sha256(evidence).hexdigest())
    record_sha = fixture_digest(fixture)
    # A successful correction is only conditional on the registry fixture.
    if result.status != 'CONDITIONAL_COMPUTATION_PASS_NOT_PROMOTED':
        return RegistryResult(result.status, task_id, record_sha, digest,
                              None, fixture.source_label)
    return RegistryResult('FIXTURE_CONDITIONAL_PASS_NOT_PROMOTED', task_id,
                          record_sha, digest, result.discovery,
                          fixture.source_label)
