"""Standalone bounded correction controller.

No repository writes. Candidate patchers accept baseline bytes and return bytes.
Verification callback is supplied by caller; it must attest compiler/axiom checks.
This controller does not authenticate that callback or validate Lean itself.
"""
from __future__ import annotations
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Callable, Iterable


@dataclass(frozen=True)
class Candidate:
    name: str
    correct: Callable[[bytes], bytes]


@dataclass(frozen=True)
class Verification:
    compile_pass: bool
    axiom_pass: bool
    authenticated: bool = False
    detail: str = ""


@dataclass(frozen=True)
class Attempt:
    name: str
    status: str
    baseline_sha256: str
    candidate_sha256: str | None
    detail: str


@dataclass(frozen=True)
class Result:
    status: str
    baseline_sha256: str
    accepted_name: str | None
    accepted_bytes: bytes | None
    attempts: tuple[Attempt, ...]


def _sha(data: bytes) -> str:
    return sha256(data).hexdigest()


def run_bounded(
    read_authoritative: Callable[[], bytes],
    candidates: Iterable[Candidate],
    verify: Callable[[bytes], Verification],
    *,
    max_attempts: int = 2,
    max_candidate_bytes: int = 2_000_000,
    require_authenticated: bool = True,
) -> Result:
    """Evaluate isolated alternatives against an unchanged authority.

    No promotion, writing, commits or rollback is performed. Fails closed on
    unexpected exceptions, non-boolean verifier fields, or authority changes.
    Caller must ensure read_authoritative covers the full protected state.
    """
    if not isinstance(max_attempts, int) or isinstance(max_attempts, bool) or not 1 <= max_attempts <= 8:
        raise ValueError("max_attempts must be in [1, 8]")
    if not isinstance(max_candidate_bytes, int) or isinstance(max_candidate_bytes, bool) or not 1 <= max_candidate_bytes <= 10_000_000:
        raise ValueError("invalid size cap")
    original = read_authoritative()
    if not isinstance(original, bytes):
        raise TypeError("authoritative state must be bytes")
    baseline = _sha(original)
    attempts: list[Attempt] = []
    try:
        for index, candidate in enumerate(candidates):
            if index >= max_attempts:
                break
            candidate_hash = None
            try:
                # Recheck before and after each candidate: race/tamper guard.
                if read_authoritative() != original:
                    raise RuntimeError("AUTHORITATIVE_STATE_CHANGED")
                proposal = candidate.correct(bytes(original))
                if not isinstance(proposal, bytes):
                    raise TypeError("candidate must return bytes")
                if len(proposal) > max_candidate_bytes:
                    raise ValueError("CANDIDATE_SIZE_LIMIT")
                candidate_hash = _sha(proposal)
                if proposal == original:
                    raise ValueError("NO_OP_CANDIDATE")
                verdict = verify(proposal)
                if not isinstance(verdict, Verification):
                    raise TypeError("invalid verification receipt")
                if not all(type(v) is bool for v in (verdict.compile_pass, verdict.axiom_pass, verdict.authenticated)):
                    raise TypeError("non-boolean verification flag")
                if read_authoritative() != original:
                    raise RuntimeError("AUTHORITATIVE_STATE_CHANGED")
                if (verdict.compile_pass and verdict.axiom_pass
                    and (verdict.authenticated or not require_authenticated)):
                    attempts.append(Attempt(candidate.name, "ACCEPTED_ISOLATED", baseline, candidate_hash, verdict.detail))
                    return Result("CANDIDATE_VERIFIED_NOT_PROMOTED", baseline, candidate.name, proposal, tuple(attempts))
                attempts.append(Attempt(candidate.name, "REJECTED", baseline, candidate_hash, verdict.detail))
            except Exception as exc:
                msg = f"{type(exc).__name__}: {str(exc)[:160]}"
                attempts.append(Attempt(candidate.name, "ERROR", baseline, candidate_hash, msg))
                if read_authoritative() != original:
                    return Result("BLOCKED_AUTHORITY_CHANGED", baseline, None, None, tuple(attempts))
        if read_authoritative() != original:
            return Result("BLOCKED_AUTHORITY_CHANGED", baseline, None, None, tuple(attempts))
        return Result("NOT_VERIFIED", baseline, None, None, tuple(attempts))
    except Exception:
        # No changes are made by this controller, and no accepted output escapes.
        return Result("NOT_VERIFIED", baseline, None, None, tuple(attempts))
