"""Exact, bounded scientific candidate verifier. Research-only; no production auth.

The trusted verifier computes equality itself; candidate JSON success claims are
ignored and prohibited. No subprocesses, network or repository writes.
"""
from __future__ import annotations

import json
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from typing import Callable

from controller import Candidate, Result, Verification, run_bounded

MAX_INPUT = 65536
MAX_DEGREE = 64
MAX_DIGITS = 80
EXPECTED_SCIENTIFIC_SHA256 = "9986a6cee01e2cecd3f85c36d8e1501c3d1fd2894fd1ae8859a1155b1214dabe"
EXPECTED_SOURCES_SHA256 = "64e2268a012d53b6276d05e63397a5510305e3242ff95e737c02a3d813886f18"


def validate_checkpoint(root: Path) -> dict[str, str]:
    """Read only exact checkpoint source hashes, not a code-signature check."""
    names = {
        'scientific': ('src/research_agent_toolkit/scientific.py', EXPECTED_SCIENTIFIC_SHA256),
        'sources': ('src/research_agent_toolkit/science_sources.py', EXPECTED_SOURCES_SHA256),
    }
    output = {}
    for label, (relative, expected) in names.items():
        path = root / relative
        raw = path.read_bytes()
        actual = sha256(raw).hexdigest()
        if actual != expected:
            raise ValueError('CHECKPOINT_HASH_MISMATCH:' + label)
        output[label] = actual
    return output


def rational(s: object) -> Fraction:
    if type(s) is not str or len(s) > MAX_DIGITS or not s:
        raise ValueError('INVALID_RATIONAL')
    # Integer or integer/integer only. No Python expression, floats or exponent.
    import re
    if not re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?', s):
        raise ValueError('INVALID_RATIONAL')
    f = Fraction(s)
    if f.numerator.bit_length() > 256 or f.denominator.bit_length() > 256:
        raise ValueError('RATIONAL_LIMIT')
    return f


def parse_trial(data: bytes) -> tuple[tuple[Fraction, ...], tuple[Fraction, ...]]:
    if type(data) is not bytes or len(data) > MAX_INPUT:
        raise ValueError('INPUT_LIMIT')
    def unique_object(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError('DUPLICATE_JSON_KEY')
            obj[key] = value
        return obj
    obj = json.loads(data.decode('utf-8', 'strict'),
                     object_pairs_hook=unique_object)
    if type(obj) is not dict or set(obj) != {'left', 'right'}:
        raise ValueError('INVALID_TRIAL_SCHEMA')
    sides = []
    for key in ('left', 'right'):
        seq = obj[key]
        if type(seq) is not list or not 1 <= len(seq) <= MAX_DEGREE + 1:
            raise ValueError('DEGREE_LIMIT')
        sides.append(tuple(rational(x) for x in seq))
    return sides[0], sides[1]


def trim(seq: tuple[Fraction, ...]) -> tuple[Fraction, ...]:
    end = len(seq)
    while end > 1 and seq[end - 1] == 0:
        end -= 1
    return seq[:end]


def evaluate(poly: tuple[Fraction, ...], x: int) -> Fraction:
    acc = Fraction(0)
    for c in reversed(poly):
        acc = acc * x + c
    return acc


def trusted_verify(trial: bytes) -> Verification:
    """Independent exact checks. No user-supplied verdict or authentication."""
    try:
        left, right = parse_trial(trial)
        # Independent tests: canonical coefficient comparison and Horner evaluation
        # at degree+1 distinct integer points; either failure rejects.
        coefficient_pass = trim(left) == trim(right)
        max_degree = max(len(left), len(right)) - 1
        evaluations_pass = all(evaluate(left, x) == evaluate(right, x)
                               for x in range(max_degree + 1))
        passed = coefficient_pass and evaluations_pass
        return Verification(compile_pass=passed, axiom_pass=passed,
                            authenticated=False,
                            detail=('EXACT_POLYNOMIAL_IDENTITY' if passed
                                    else 'POLYNOMIAL_MISMATCH'))
    except (ValueError, TypeError, UnicodeError, json.JSONDecodeError, ZeroDivisionError) as exc:
        return Verification(False, False, False, 'INVALID:' + type(exc).__name__)


def evaluate_candidates(baseline: bytes, candidates: list[Candidate], *, max_attempts: int = 2) -> Result:
    """Trusted local computation only. Not Lean verification or authentication.

    The baseline is immutable bytes. Candidate callback code must be trusted;
    this API does not sandbox arbitrary Python or access an on-disk repository.
    """
    if type(baseline) is not bytes or len(baseline) > MAX_INPUT:
        raise ValueError('INVALID_BASELINE')
    parse_trial(baseline)
    # The generic controller's `authenticated` flag is intentionally not
    # asserted: this is computation-only, never a production certificate.
    return run_bounded(lambda: baseline, candidates, trusted_verify,
                       max_attempts=max_attempts,
                       max_candidate_bytes=MAX_INPUT,
                       require_authenticated=False)


def claim_classification(result: Result) -> str:
    """Translate verified local result into a bounded, non-proof claim."""
    if result.status != 'CANDIDATE_VERIFIED_NOT_PROMOTED':
        return 'NOT_VERIFIED'
    if result.accepted_bytes is None:
        return 'NOT_VERIFIED'
    if not (trusted_verify(result.accepted_bytes).compile_pass and
            trusted_verify(result.accepted_bytes).axiom_pass):
        return 'NOT_VERIFIED'
    return 'COMPUTATION_PASS'
