"""Four fixed, read-only scientific CLI fixtures, verified by independent host checks.

The scientific package is staged by the launch command in an isolated temporary
folder and selected by URF_SCIENCE_STAGE. No arbitrary caller payloads are used.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from fractions import Fraction
from docker_bridge import limited_run

REV='605aca6330c7b834c09eae77275763b8a374f864'
SOURCE_PATH='tools/research-agent-toolkit/src/research_agent_toolkit/lean_exact.py'
FIXTURES={
 'integrate': {'coefficients':[0,1], 'lower':0, 'upper':1},
 'compare': {'published':'1/2','candidate':'1/2'},
 'cycle-locality': {'n':3,'edges':[[0,1],[1,2],[0,2]],'radius':1,'max_states':65536},
}
MAX_RECEIPT=8192

def unique_pairs(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError('DUPLICATE_KEY')
        out[k]=v
    return out

def decode(receipt):
    data=json.loads(receipt.decode('utf-8','strict'),object_pairs_hook=unique_pairs)
    if type(data) is not dict: raise ValueError('NON_OBJECT')
    return data

def _run_checked(cmd, *, timeout=15, max_output=8192):
    code,out,err=limited_run(cmd,timeout,max_output=max_output)
    if code: raise ValueError('NONZERO_EXIT')
    if err.strip(): raise ValueError('UNEXPECTED_STDERR')
    return out

def verify(operation, data, expected_source=None, repo=None):
    """Fail closed; no receipt status alone constitutes independent verification."""
    if operation=='integrate':
        if set(data)!={'status','value'} or data.get('status')!='COMPUTATION_PASS' or type(data['value']) is not str or Fraction(data['value'])!=Fraction(1,2):
            raise ValueError('INTEGRAL_WITNESS_MISMATCH')
        # Exact independent integral: ∫0^1 x dx = (1²−0²)/2
        return {'status':'COMPUTATION_PASS','detail':'HOST_CHECKED_INTEGRAL','answer':'1/2','promotion':'NOT_PERFORMED'}
    if operation=='compare':
        if set(data)!={'published','candidate','difference','discrepancy','status','published_error_confirmed'}:
            raise ValueError('COMPARE_RECEIPT_SCHEMA')
        if (data['published'],data['candidate'],data['difference'])!=('1/2','1/2','0') or data['discrepancy'] is not False or data['published_error_confirmed'] is not False or data['status']!='COMPUTATION_PASS':
            raise ValueError('COMPARE_MISMATCH')
        return {'status':'COMPUTATION_PASS','detail':'HOST_CHECKED_COMPARISON','answer':'difference = 0','promotion':'NOT_PERFORMED'}
    if operation=='cycle-locality':
        if set(data)!={'equivalent','global_dimension','local_span_dimension','states_checked','status'}:
            raise ValueError('CYCLE_RECEIPT_SCHEMA')
        if (type(data['global_dimension']) is not int or data['global_dimension']!=1
            or type(data['local_span_dimension']) is not int or data['local_span_dimension']!=1
            or data['equivalent'] is not True or data['status']!='COMPUTATION_PASS'
            or type(data['states_checked']) is not int or not 1<=data['states_checked']<=65536):
            raise ValueError('TRIANGLE_WITNESS_MISMATCH')
        # Independent global rank = |E|-|V|+components = 3-3+1.
        # Local value is agreement with the fixed small fixture, not a general theorem.
        return {'status':'COMPUTATION_PASS','detail':'TRIANGLE_FIXTURE_MATCH',
                'answer':'global=1, local=1, equivalent=true','states_checked':data['states_checked'],
                'promotion':'NOT_PERFORMED'}
    if operation=='source':
        if not isinstance(expected_source,bytes) or not isinstance(repo,str):
            raise ValueError('SOURCE_PREREQUISITES_MISSING')
        required={'path','repository','revision','sha256','source'}
        if set(data)!=required:
            raise ValueError('SOURCE_RECEIPT_SCHEMA')
        digest=hashlib.sha256(expected_source).hexdigest()
        if (data['path']!=SOURCE_PATH or data['repository']!=repo or data['revision']!=REV
            or data['sha256']!=digest or type(data['source']) is not str
            or data['source'].encode('utf-8')!=expected_source):
            raise ValueError('SOURCE_MISMATCH')
        return {'status':'COMPUTATION_PASS','detail':'REPOSITORY_RELATIVE_INTEGRITY',
                'answer':'SHA256='+digest,'promotion':'NOT_PERFORMED'}
    raise ValueError('UNREGISTERED_OPERATION')

def run(operation):
    if operation not in (*FIXTURES,'source'):
        return {'status':'UNSUPPORTED','detail':'UNREGISTERED_SCIENCE_OPERATION'}
    stage=os.environ.get('URF_SCIENCE_STAGE','')
    repo=os.environ.get('URF_SCIENCE_REPO','')
    if not stage or not repo:
        return {'status':'INCOMPLETE','detail':'SCIENTIFIC_STAGE_NOT_CONFIGURED'}
    root=Path(stage).resolve()
    expected=Path(repo).expanduser().resolve()
    if not (root/'research_agent_toolkit'/'scientific.py').is_file() or not (expected/'.git').exists():
        return {'status':'INCOMPLETE','detail':'STAGE_OR_REPOSITORY_MISSING'}
    try:
        actual=_run_checked(['git','-C',str(expected),'rev-parse','HEAD']).decode().strip()
        if actual!=REV: raise ValueError('REVISION_CHANGED')
        payload=FIXTURES.get(operation,{'repo':str(expected),'revision':REV,'path':SOURCE_PATH})
        # Reject potentially contaminating Git overrides; explicit env isolates Python imports.
        if os.environ.get('GIT_DIR') or os.environ.get('GIT_WORK_TREE'):
            raise ValueError('UNTRUSTED_GIT_ENVIRONMENT')
        cmd=['/usr/bin/env','-u','GIT_DIR','-u','GIT_WORK_TREE',
             'PYTHONPATH='+str(root),'PYTHONDONTWRITEBYTECODE=1',
             sys.executable,'-B','-m','research_agent_toolkit.cli',
             'science',operation,json.dumps(payload,separators=(',',':'))]
        expected_blob=None
        if operation=='source':
            expected_blob=_run_checked(['git','-C',str(expected),'show',REV+':'+SOURCE_PATH], max_output=32768)
        raw=_run_checked(cmd,max_output=65536 if operation=='source' else 8192)
        receipt=decode(raw)
        return verify(operation,receipt,expected_blob,str(expected))
    except (ValueError,UnicodeError,TypeError,subprocess.TimeoutExpired,FileNotFoundError,OSError,ZeroDivisionError) as exc:
        kind='TIMEOUT' if isinstance(exc,subprocess.TimeoutExpired) else 'FAIL_CLOSED'
        return {'status':'INCOMPLETE','detail':'SCIENTIFIC_CLI_'+kind}
