#!/bin/zsh
set -euo pipefail

here="$(cd "$(dirname "$0")" && pwd)"
cd "$here"

sample_id="CARBON-20260718T151252Z-001"
workdir="$(mktemp -d)"
repo="$workdir/chronos-urf-rr"

cleanup() {
  rm -rf "$workdir"
}
trap cleanup EXIT INT TERM

python3 \
  "$here/validate_measurement_bundle.py" \
  "$here" \
  "$sample_id"

gh repo clone \
  "inaciovasquez2020/chronos-urf-rr" \
  "$repo" \
  -- \
  --depth 1

python_bin="${PYTHON:-python3}"

if ! "$python_bin" - <<'PY_DEPS' >/dev/null 2>&1
import flint
import numpy as np
import scipy

assert hasattr(np, "trapezoid")
PY_DEPS
then
  python_bin="$workdir/.venv/bin/python"
  python3 -m venv "$workdir/.venv"
  "$python_bin" -m pip install --quiet --upgrade pip
  "$python_bin" -m pip install --quiet \
    numpy \
    scipy \
    python-flint
fi

(
  cd "$repo"

  "$python_bin" carbon_sample_analysis.py \
    --metadata "$here/sample_metadata.json" \
    --ct-density "$here/ct_density.csv" \
    --residual-stress "$here/residual_stress.csv" \
    --output "$here/convergence_uncertainty_report.json" \
    --draws 10000 \
    --seed 20260718
)

printf '%s\n' \
  "RESULT := calibrated bundle analyzed" \
  "OUTPUT := $here/convergence_uncertainty_report.json" \
  "BOUNDARY := conditional numerical result; not interval-certified"
