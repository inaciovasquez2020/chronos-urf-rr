# Measurement request

## Specimen

Sample ID: `CARBON-20260718T151252Z-001`

All specimen labels, instrument exports, calibration records, and reports must
use this exact identifier.

## Required physical measurements

### Metadata

Complete every null field in `sample_metadata.json` using calibrated,
traceable records from this specimen.

Required items include:

- exact material grade or composition;
- calibrated mass and standard uncertainty;
- calibrated spherical radius and standard uncertainty;
- specimen temperature and uncertainty;
- observer radius and uncertainty;
- CT instrument, calibration identifier, calibration date, and density method;
- residual-stress instrument, calibration identifier, and calibration date;
- actual acquisition timestamp with timezone;
- provenance sufficient to trace every value to the specimen and instrument.

Set:

`measurement_status = "MEASURED"`

### CT-density export

Return `ct_density.csv` with at least four measured radial rows.

Header:

`r_m,rho_kg_m3,rho_uncertainty_kg_m3`

Requirements:

- SI units;
- strictly increasing radii;
- positive finite density;
- nonnegative finite standard uncertainty;
- final radius consistent with the calibrated specimen radius.

### Residual-stress export

Return `residual_stress.csv` with at least four measured radial rows.

Header:

`r_m,sigma_rr_pa,sigma_tt_pa,sigma_rr_uncertainty_pa,sigma_tt_uncertainty_pa`

Requirements:

- SI units;
- strictly increasing radii;
- signed radial and tangential stresses preserved;
- nonnegative finite standard uncertainties;
- final radius consistent with the calibrated specimen radius.

## Prohibited substitutions

Do not use:

- handbook or nominal material properties;
- simulated or interpolated profiles without measured source rows;
- measurements from another specimen;
- invented acquisition or calibration identifiers;
- administrative timestamps as acquisition timestamps.

## Validation

After inserting the completed files, run:

```sh
python3 validate_measurement_bundle.py . "CARBON-20260718T151252Z-001"
```

A successful package prints:

`RESULT := calibrated measurement bundle validated`
